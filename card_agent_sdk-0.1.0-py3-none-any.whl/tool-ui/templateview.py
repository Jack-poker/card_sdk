import base64
import re

import flet as ft
import svg2png_py
from svg2png_py import svg2png_py

from cameraoverlay import get_latest_photo_uri

template_preview_path = "/home/quantumbytes/Documents/Q_PROJECTS/GEN_CARD/sdk/card_sdk/templates/front.card.temp.kaascan"
template_path = "/home/quantumbytes/Documents/Q_PROJECTS/GEN_CARD/sdk/card_sdk/templates/front.card.kaascan"
back_template_path = "/home/quantumbytes/Documents/Q_PROJECTS/GEN_CARD/sdk/card_sdk/templates/back.card.kaascan"
db = svg2png_py.FontDatabase.system()

# The back template only exposes these placeholders; fill them with
# reasonable defaults so the preview renders nicely.
_BACK_DEFAULTS = {
    "data_qrcode": "",
    "school_name": "SCHOOL NAME",
}

# id of the (large, empty) student-photo <image> slot in the front template.
_PHOTO_IMAGE_ID = "image5"


def inject_photo(svg_string: str, photo_uri: str | None) -> str:
    """Swap the student-photo ``<image>`` href for the latest camera photo.

    The front template's photo slot is an ``<image id="image5">`` element
    whose ``href``/``xlink:href`` is empty; the SDK pipeline never fills it
    (there is no ``{image_base64}`` placeholder), so we splice the photo in
    right before rendering.
    """
    if not photo_uri:
        return svg_string

    def _swap(match):
        tag = match.group(0)
        return re.sub(
            r'(xlink:href|href)="[^"]*"',
            lambda m: f'{m.group(1)}="{photo_uri}"',
            tag,
        )

    return re.sub(
        r'<image(?=[^>]*id="' + _PHOTO_IMAGE_ID + r'")[^>]*>',
        _swap,
        svg_string,
        flags=re.S,
    )


def _render_preview():
    with open(template_preview_path, "r") as template_file:
        svg_string = template_file.read()
    svg_string = inject_photo(svg_string, get_latest_photo_uri())
    return svg2png_py.svg_to_png(
        svg_string, db, options=svg2png_py.RenderOptions(dpi=300)
    )


def _render_back_preview():
    with open(back_template_path, "r") as template_file:
        svg_string = template_file.read()
    for key, value in _BACK_DEFAULTS.items():
        svg_string = svg_string.replace("{" + key + "}", value)
    return svg2png_py.svg_to_png(
        svg_string, db, options=svg2png_py.RenderOptions(dpi=300)
    )


# `src` accepts a base64 string directly; `expand` + `fit` make the preview
# scale with the window instead of a fixed 800px width.
_template_image = ft.Image(
    expand=True,
    src=base64.b64encode(_render_preview()).decode(),
    fit=ft.BoxFit.CONTAIN,
    gapless_playback=True,
)

_back_template_image = ft.Image(
    expand=True,
    src=base64.b64encode(_render_back_preview()).decode(),
    fit=ft.BoxFit.CONTAIN,
    gapless_playback=True,
)


def template_view():
    return _template_image


def template_view_back():
    return _back_template_image


def _safe_update(control):
    try:
        control.update()
    except RuntimeError:
        # Control not attached to a page yet (e.g. headless/startup) -
        # the new src is already stored and will render on first attach.
        pass


def refresh_template():
    _template_image.src = base64.b64encode(_render_preview()).decode()
    _safe_update(_template_image)


def refresh_back_template():
    _back_template_image.src = base64.b64encode(_render_back_preview()).decode()
    _safe_update(_back_template_image)
