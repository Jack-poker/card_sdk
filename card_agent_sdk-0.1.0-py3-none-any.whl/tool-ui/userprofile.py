import flet as ft


def user_profile():
    return (
        ft.Container(
            width=300,
            padding=ft.Padding(top=100, bottom=100, right=100, left=100),
            border=ft.Border(
                top=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
                bottom=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
                right=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
                left=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
            ),
            content=ft.Image(
                expand=True,
                fit=ft.BoxFit.COVER,
                src="https://admin.kaascan.com/assets/86637cf5-30c1-4046-9cee-f2e3267e52de",
            ),
        ),
    )[0]
