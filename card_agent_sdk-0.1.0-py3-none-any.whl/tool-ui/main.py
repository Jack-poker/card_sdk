import json
import os
import flet as ft
from templateview import (
    template_view,
    template_view_back,
    refresh_template,
    refresh_back_template,
)
from templatecustomizer import template_customizer
from cardgenerator import generation_panel
from cameraoverlay import camera_overlay, stop_active_overlay
from camerascreen import camera_screen, stop_camera_screen
from filemanager import output_screen


def refresh_all():
    """Re-render both the front and back card previews."""
    refresh_template()
    refresh_back_template()


# Below this window width (px) the sidebar rail collapses to icons-only.
_COLLAPSE_BREAKPOINT = 900


def _window_width(page) -> int:
    """Current window width with sane fallbacks (headless-safe)."""
    try:
        return int(page.width or page.window.width or 1280)
    except Exception:
        return 1280


def _screen(icon, title, subtitle, controls):
    """A full-height, independently-scrolling screen with a header row."""
    return ft.Container(
        expand=True,
        padding=ft.Padding(top=24, bottom=24, right=28, left=28),
        content=ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            controls=[
                ft.Row(
                    spacing=12,
                    controls=[
                        ft.Container(
                            padding=ft.Padding(top=10, bottom=10, right=10, left=10),
                            bgcolor=ft.Colors.GREY_900,
                            border_radius=10,
                            border=ft.Border.all(1, ft.Colors.GREEN),
                            content=ft.Icon(icon, color=ft.Colors.GREEN),
                        ),
                        ft.Column(
                            spacing=2,
                            controls=[
                                ft.Text(
                                    title,
                                    size=24,
                                    weight=ft.FontWeight.BOLD,
                                    font_family="rotten",
                                ),
                                ft.Text(
                                    subtitle,
                                    size=12,
                                    color=ft.Colors.GREY_400,
                                ),
                            ],
                        ),
                    ],
                ),
                ft.Divider(color=ft.Colors.GREY_800, height=28),
                *controls,
            ],
        ),
    )


def _preview_screen(page):
    """Screen 1 — real-time card design studio (front/back + customizer)."""
    front_panel = ft.Container(
        col={"xs": 12, "md": 12},
        alignment=ft.Alignment.CENTER,
        content=template_view(),
    )
    back_panel = ft.Container(
        col={"xs": 12, "md": 6},
        visible=False,
        alignment=ft.Alignment.CENTER,
        content=template_view_back(),
    )

    def toggle_back_card(e):
        show_back = e.control.value
        back_panel.visible = show_back
        # When both cards are shown, split the row in half; otherwise the
        # front card takes the full width.
        front_panel.col = {"xs": 12, "md": 6} if show_back else {"xs": 12, "md": 12}
        page.update()

    return _screen(
        ft.Icons.DESIGN_SERVICES,
        "CARD DESIGN STUDIO",
        "Real-time front & back preview with live color customization",
        [
            ft.Row(
                controls=[
                    ft.Switch(
                        label="Show back card",
                        value=False,
                        on_change=toggle_back_card,
                    ),
                    ft.Container(expand=True),
                    ft.TextButton(
                        icon=ft.Icons.PLAY_ARROW,
                        content="Preview",
                        on_click=lambda e: refresh_all(),
                    ),
                    ft.TextButton(
                        icon=ft.Icons.REFRESH,
                        content="Refresh",
                        on_click=lambda e: refresh_all(),
                    ),
                ],
            ),
            ft.ResponsiveRow(
                spacing=16,
                run_spacing=16,
                controls=[
                    ft.Container(
                        col={"xs": 12, "md": 7},
                        content=ft.Column(
                            spacing=12,
                            controls=[
                                ft.ResponsiveRow(
                                    spacing=16,
                                    run_spacing=16,
                                    controls=[front_panel, back_panel],
                                ),
                            ],
                        ),
                    ),
                    ft.Container(
                        col={"xs": 12, "md": 5},
                        content=template_customizer(),
                    ),
                ],
            ),
        ],
    )


def _generate_screen(page):
    """Screen 2 — the SDK-linked AI card generator (has its own header)."""
    return ft.Container(
        expand=True,
        padding=ft.Padding(top=24, bottom=24, right=28, left=28),
        content=ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            controls=[generation_panel(page)],
        ),
    )


def _about_screen():
    """Screen 4 — branding, QR and feature rundown."""
    qr_path = "/home/quantumbytes/Documents/Q_PROJECTS/GEN_CARD/sdk/card_sdk/tmp/card_qrcode.png"
    qr = (
        ft.Image(
            src=qr_path,
            width=140,
            height=140,
            fit=ft.BoxFit.CONTAIN,
            border_radius=12,
        )
        if os.path.exists(qr_path)
        else ft.Container(
            width=140,
            height=140,
            bgcolor=ft.Colors.GREY_900,
            border_radius=12,
            alignment=ft.Alignment.CENTER,
            content=ft.Icon(ft.Icons.QR_CODE, size=56, color=ft.Colors.GREY_500),
        )
    )
    return _screen(
        ft.Icons.INFO_OUTLINE,
        "ABOUT",
        "CARD SDK PREVIEW — built on the Kaascan card pipeline",
        [
            ft.ResponsiveRow(
                spacing=16,
                run_spacing=16,
                controls=[
                    ft.Container(
                        col={"xs": 12, "md": 4},
                        alignment=ft.Alignment.CENTER,
                        content=qr,
                    ),
                    ft.Container(
                        col={"xs": 12, "md": 8},
                        content=ft.Column(
                            spacing=10,
                            controls=[
                                ft.Text(
                                    "█▀▀ ▄▀█ █▀█ █▀▄   █▀ █▀▄ █▄▀\n"
                                    "█▄▄ █▀█ █▀▄ █▄▀   ▄█ █▄▀ █░█",
                                    font_family="rotten",
                                    size=20,
                                ),
                                ft.Text(
                                    "Made with love by QuantumBytes",
                                    size=13,
                                    color=ft.Colors.GREY_400,
                                ),
                                ft.Text(
                                    "• Preview — real-time card design studio\n"
                                    "• Generate — batch card generation through the local SDK\n"
                                    "• Camera / Dev — push photos to the endpoint and they become student photos\n"
                                    "• Output — browse, preview & print the generated card PDFs",
                                    size=13,
                                    color=ft.Colors.GREY_400,
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ],
    )


def build_shell(page):
    """The pro layout: sidebar + screen stack + floating camera avatar."""
    # Start the photo endpoint FIRST so the camera screen's endpoint URL is
    # computed from the actually-bound port (not the default one).
    cam = camera_overlay(page)

    # Every screen is built once and kept in a Stack; the rail toggles which
    # one is visible — no whole-page scrolling, each screen scrolls itself.
    screens = [
        _preview_screen(page),
        _generate_screen(page),
        camera_screen(page),
        output_screen(page),
        _about_screen(),
    ]
    views = []
    for i, screen in enumerate(screens):
        views.append(ft.Container(expand=True, content=screen, visible=(i == 0)))

    def switch_screen(e):
        idx = e.control.selected_index
        for i, view in enumerate(views):
            view.visible = i == idx
        page.update()

    brand_icon = ft.Icon(ft.Icons.BADGE, color=ft.Colors.GREEN)
    brand_text = ft.Text(
        "CARD SDK",
        size=16,
        weight=ft.FontWeight.BOLD,
        font_family="gilroy",
    )

    rail = ft.NavigationRail(
        selected_index=0,
        extended=True,
        min_width=64,
        min_extended_width=224,
        bgcolor=ft.Colors.GREY_900,
        indicator_color=ft.Colors.with_opacity(0.30, ft.Colors.GREEN),
        label_type=ft.NavigationRailLabelType.ALL,
        group_alignment=-0.9,
        destinations=[
            ft.NavigationRailDestination(
                icon=ft.Icons.DESIGN_SERVICES,
                label="Preview",
                tooltip="Preview",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.AUTO_AWESOME,
                label="Generate",
                tooltip="Generate",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.PHOTO_CAMERA,
                label="Camera / Dev",
                tooltip="Camera / Dev",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.FOLDER_OPEN,
                label="Output",
                tooltip="Output files",
            ),
            ft.NavigationRailDestination(
                icon=ft.Icons.INFO_OUTLINE,
                label="About",
                tooltip="About",
            ),
        ],
        on_change=switch_screen,
    )

    def apply_rail(e=None):
        """Collapse the rail to icons-only on narrow windows."""
        # Prefer the RESIZED event's payload (exact new size); fall back to
        # the page's current width, then a safe default.
        width = None
        if e is not None and getattr(e, "data", None):
            try:
                width = int(json.loads(e.data).get("width"))
            except Exception:
                width = None
        if width is None:
            width = _window_width(page)
        collapsed = width < _COLLAPSE_BREAKPOINT
        rail.extended = not collapsed
        brand_text.visible = not collapsed
        try:
            page.update()
        except Exception:
            pass

    # Window events: resize -> adapt the rail; close -> free resources.
    try:
        page.window.on_event = lambda e: (
            apply_rail(e)
            if e.type == ft.WindowEventType.RESIZED
            else (
                (stop_active_overlay(), stop_camera_screen())
                if e.type == ft.WindowEventType.CLOSE
                else None
            )
        )
    except Exception:
        pass
    apply_rail()  # apply once with the current window size

    sidebar = ft.Container(
        bgcolor=ft.Colors.GREY_900,
        padding=ft.Padding(top=20, bottom=20, right=8, left=16),
        content=ft.Column(
            expand=True,
            controls=[
                ft.Row(spacing=10, controls=[brand_icon, brand_text]),
                ft.Divider(color=ft.Colors.GREY_800, height=28),
                # NavigationRail errors with "height is unbounded" as a bare
                # Column child — wrap it in an expanded control that fills the
                # sidebar's remaining height and gives the rail bounded bounds.
                ft.Container(expand=True, content=rail),
            ],
        ),
    )

    return ft.Stack(
        expand=True,
        controls=[
            ft.Row(
                expand=True,
                vertical_alignment=ft.CrossAxisAlignment.STRETCH,
                controls=[
                    sidebar,
                    ft.VerticalDivider(width=1, color=ft.Colors.GREY_800),
                    ft.Container(
                        expand=True,
                        content=ft.Stack(expand=True, controls=views),
                    ),
                ],
            ),
            # Floating live camera avatar — freely draggable anywhere.
            cam,
        ],
    )


def main(page: ft.Page):
    page.title = "CARD SDK PREVIEW"
    page.bgcolor = ft.Colors.BLACK_87
    page.padding = 0
    page.spacing = 0

    # Window events (resize -> rail collapse, close -> free resources) are
    # wired inside build_shell so the shell stays self-contained.
    page.add(build_shell(page))


if __name__ == "__main__":
    ft.run(main)
