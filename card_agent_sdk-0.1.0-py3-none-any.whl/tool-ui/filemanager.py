"""Output file manager.

Browses the SDK's generated cards (``output/<school>/<class>/`` — the way the
SDK *classifies* cards), previews them (PDF pages via PyMuPDF, SVG via the
same renderer the preview screen uses) and prints them like a pro desktop app:
Windows opens the native print dialog, Linux/macOS sends to the default
printer via ``lpr``/``lp``, with the PDF viewer as a fallback.
"""

import base64
import os
import pathlib
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime

import flet as ft

# Make sure the *local* card_sdk wins over any site-packages copy.
_SDK_ROOT = pathlib.Path(__file__).resolve().parent.parent
if str(_SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(_SDK_ROOT))

from card_sdk.card import output_folder  # noqa: E402

# Where generated cards land: <output_folder>/output/<school>/<class>/
OUTPUT_ROOT = pathlib.Path(output_folder).resolve() / "output"

_FILE_EXTS = (".pdf", ".svg", ".png", ".jpg", ".jpeg")


def output_root() -> pathlib.Path:
    """The directory the file manager browses (created on demand)."""
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    return OUTPUT_ROOT


def list_files(folder: pathlib.Path) -> list[pathlib.Path]:
    """Files in a class folder, newest first."""
    if not folder.is_dir():
        return []
    files = [p for p in folder.iterdir() if p.suffix.lower() in _FILE_EXTS]
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return files


# --------------------------------------------------------------------------- #
# previews                                                                     #
# --------------------------------------------------------------------------- #
def _pdf_preview_b64(path: pathlib.Path, width: int = 420) -> str | None:
    """Render the first page of a PDF to a PNG (base64) via PyMuPDF."""
    try:
        import fitz

        doc = fitz.open(path)
        page = doc[0]
        zoom = max(0.1, width / max(page.rect.width, 1.0))
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
        png = pix.tobytes("png")
        doc.close()
        return base64.b64encode(png).decode()
    except Exception:
        return None


def _svg_preview_b64(path: pathlib.Path) -> str | None:
    try:
        import svg2png_py
        from svg2png_py import svg2png_py

        db = svg2png_py.FontDatabase.system()
        svg = path.read_text(encoding="utf-8", errors="replace")
        png = svg2png_py.svg_to_png(svg, db, options=svg2png_py.RenderOptions(dpi=96))
        return base64.b64encode(png).decode()
    except Exception:
        return None


def _image_preview_b64(path: pathlib.Path) -> str | None:
    try:
        return base64.b64encode(path.read_bytes()).decode()
    except Exception:
        return None


# Rendered previews (PDF/SVG) are always PNG; raster files keep their own mime.
_PREVIEW_MIME = {
    ".pdf": "image/png",
    ".svg": "image/png",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
}


def preview_b64(path: pathlib.Path, width: int = 420) -> str | None:
    """Best-effort base64 preview (no data-URI prefix) for any card file."""
    ext = path.suffix.lower()
    if ext == ".pdf":
        return _pdf_preview_b64(path, width)
    if ext == ".svg":
        return _svg_preview_b64(path)
    if ext in (".png", ".jpg", ".jpeg"):
        return _image_preview_b64(path)
    return None


def preview_uri(path: pathlib.Path, width: int = 420) -> str | None:
    """Data-URI ready preview — Flet Image.src needs the ``data:`` prefix."""
    b64 = preview_b64(path, width)
    if not b64:
        return None
    mime = _PREVIEW_MIME.get(path.suffix.lower(), "image/png")
    return f"data:{mime};base64,{b64}"


# --------------------------------------------------------------------------- #
# open / print (pro software behaviour)                                        #
# --------------------------------------------------------------------------- #
def _open_path(path: pathlib.Path):
    """Open a file/folder with the OS default application."""
    try:
        if platform.system() == "Windows":
            os.startfile(str(path))  # noqa: S606
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception:
        pass


def _cleanup_stale_tmp():
    """Best-effort cleanup of leftover .print_* temps older than 5 minutes."""
    try:
        now = time.time()
        for p in OUTPUT_ROOT.glob(".print_*.pdf"):
            try:
                if now - p.stat().st_mtime > 300:
                    p.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass


def _as_pdf(path: pathlib.Path) -> pathlib.Path:
    """Ensure we always have a PDF to send to the printer (unique temp file)."""
    if path.suffix.lower() == ".pdf":
        return path
    _cleanup_stale_tmp()
    tmp = pathlib.Path(
        tempfile.mkstemp(prefix=".print_", suffix=".pdf", dir=str(OUTPUT_ROOT))[1]
    )
    try:
        if path.suffix.lower() == ".svg":
            import cairosvg

            cairosvg.svg2pdf(url=str(path), write_to=str(tmp))
        else:
            import fitz

            doc = fitz.open()
            p = doc.new_page(width=595, height=842)
            p.insert_image(p.rect, filename=str(path))
            doc.save(str(tmp))
            doc.close()
    except Exception:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        return path
    return tmp


def _print_pdf(path: pathlib.Path) -> str:
    """Print a PDF via the platform's native path; returns a status message."""
    try:
        if platform.system() == "Windows":
            os.startfile(str(path), "print")  # noqa: S606
            return "Opened the Windows print dialog"
        if shutil.which("lpr"):
            subprocess.Popen(["lpr", str(path)])
            return "Sent to the default printer (lpr)"
        if shutil.which("lp"):
            subprocess.Popen(["lp", str(path)])
            return "Sent to the default printer (lp)"
    except Exception:
        pass
    _open_path(path)
    return "Opened the PDF — use its Print button"


def print_file(path: pathlib.Path) -> str:
    """Print a card file (converting non-PDF files first)."""
    return _print_pdf(_as_pdf(path))


def print_folder(folder: pathlib.Path) -> str:
    """Print every PDF card in a class folder, newest first."""
    pdfs = [p for p in list_files(folder) if p.suffix.lower() == ".pdf"]
    if not pdfs:
        return "No PDF cards in this folder"
    for p in pdfs:
        _print_pdf(p)
    return f"Sent {len(pdfs)} card(s) to the printer"


def _toast(page: ft.Page, message: str):
    try:
        page.open(
            ft.SnackBar(
                content=ft.Text(message, color=ft.Colors.BLACK),
                bgcolor=ft.Colors.GREEN,
                duration=2500,
            )
        )
    except Exception:
        pass


# --------------------------------------------------------------------------- #
# the screen                                                                   #
# --------------------------------------------------------------------------- #
def _folder_tile(name: str, meta: str, on_click) -> ft.Container:
    return ft.Container(
        padding=ft.Padding(top=8, bottom=8, right=10, left=10),
        border_radius=8,
        bgcolor=ft.Colors.GREY_800,
        border=ft.Border.all(1, ft.Colors.GREY_700),
        on_click=on_click,
        content=ft.Column(
            spacing=0,
            controls=[
                ft.Text(name, size=13, weight=ft.FontWeight.BOLD, max_lines=1,
                        overflow=ft.TextOverflow.ELLIPSIS),
                ft.Text(meta, size=10, color=ft.Colors.GREY_500),
            ],
        ),
    )


def output_screen(page: ft.Page) -> ft.Container:
    """The Output file-manager screen (self-contained, scrolls on its own)."""
    root = output_root()

    path_label = ft.Text(
        str(root), size=11, color=ft.Colors.GREY_500, font_family="monospace"
    )
    count_text = ft.Text("", size=12, color=ft.Colors.GREY_500)

    schools_list = ft.ListView(expand=True, spacing=4, padding=4)
    classes_list = ft.ListView(expand=True, spacing=4, padding=4)

    # GridView scrolls itself — perfect for a pro file-manager grid.
    files_grid = ft.GridView(
        max_extent=190,
        spacing=10,
        run_spacing=10,
        child_aspect_ratio=1.0,
        expand=True,
    )
    files_scroll = ft.Container(
        expand=True,
        bgcolor=ft.Colors.GREY_900,
        border_radius=12,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        padding=10,
        content=files_grid,
    )

    preview_img = ft.Image(
        src=None,
        width=560,
        height=340,
        fit=ft.BoxFit.CONTAIN,
        border_radius=10,
    )
    preview_box = ft.Container(
        height=360,
        alignment=ft.Alignment.CENTER,
        bgcolor=ft.Colors.GREY_900,
        border_radius=12,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=preview_img,
    )
    file_title = ft.Text("Select a card", size=18, weight=ft.FontWeight.BOLD)
    file_meta = ft.Text("", size=12, color=ft.Colors.GREY_400)

    print_btn = ft.ElevatedButton(
        "Print",
        icon=ft.Icons.PRINT,
        disabled=True,
        style=ft.ButtonStyle(
            color=ft.Colors.BLACK,
            bgcolor=ft.Colors.GREEN,
            text_style=ft.TextStyle(font_family="rotten", size=14),
            side=ft.BorderSide(width=1, color=ft.Colors.GREEN),
        ),
    )
    open_btn = ft.TextButton("Open", icon=ft.Icons.OPEN_IN_NEW, disabled=True)
    print_folder_btn = ft.TextButton("Print folder", icon=ft.Icons.PRINT, disabled=True)

    state = {"school": None, "class": None, "file": None}

    def pick_school(school: pathlib.Path, _e=None):
        state["school"] = school
        state["class"] = None
        state["file"] = None
        classes = sorted((p for p in school.iterdir() if p.is_dir()))
        classes_list.controls.clear()
        for cls in classes:
            n = len(list_files(cls))
            classes_list.controls.append(
                _folder_tile(cls.name, f"{n} card(s)",
                             lambda e, c=cls: pick_class(c))
            )
        files_grid.controls.clear()
        preview_img.src = None
        file_title.value = school.name
        file_meta.value = f"{len(classes)} class folder(s)"
        print_btn.disabled = True
        open_btn.disabled = True
        print_folder_btn.disabled = True
        page.update()

    def pick_class(cls: pathlib.Path, _e=None):
        state["class"] = cls
        state["file"] = None
        files = list_files(cls)
        files_grid.controls.clear()
        for f in files:
            files_grid.controls.append(_file_card(f))
        school_name = state["school"].name if state.get("school") else cls.parent.name
        file_title.value = f"{school_name}  •  {cls.name}"
        file_meta.value = f"{len(files)} card file(s)"
        preview_img.src = None
        print_btn.disabled = True
        open_btn.disabled = True
        print_folder_btn.disabled = len(files) == 0
        page.update()

    def pick_file(f: pathlib.Path, _e=None):
        state["file"] = f
        preview_img.src = preview_uri(f, 560)
        file_title.value = f.stem
        stat = f.stat()
        file_meta.value = (
            f"{f.suffix.upper()}  •  {stat.st_size / 1024:.0f} KB  •  "
            f"{datetime.fromtimestamp(stat.st_mtime):%Y-%m-%d %H:%M}"
        )
        print_btn.disabled = False
        open_btn.disabled = False
        page.update()

    def _file_card(f: pathlib.Path) -> ft.Container:
        thumb = preview_uri(f, 240)
        image = (
            ft.Image(
                src=thumb,
                width=160,
                height=100,
                fit=ft.BoxFit.CONTAIN,
                border_radius=8,
            )
            if thumb
            else ft.Container(
                width=160,
                height=100,
                bgcolor=ft.Colors.GREY_800,
                border_radius=8,
                alignment=ft.Alignment.CENTER,
                content=ft.Icon(
                    ft.Icons.PICTURE_AS_PDF, size=36, color=ft.Colors.GREY_500
                ),
            )
        )
        return ft.Container(
            padding=8,
            bgcolor=ft.Colors.GREY_900,
            border_radius=12,
            border=ft.Border.all(1, ft.Colors.GREY_800),
            on_click=lambda e, f=f: pick_file(f),
            content=ft.Column(
                spacing=6,
                controls=[
                    ft.Container(
                        height=108,
                        alignment=ft.Alignment.CENTER,
                        content=image,
                    ),
                    ft.Text(
                        f.stem[:26],
                        size=11,
                        color=ft.Colors.GREY_300,
                        max_lines=1,
                        overflow=ft.TextOverflow.ELLIPSIS,
                    ),
                ],
            ),
        )

    def on_print(_e):
        f = state.get("file")
        if f:
            _toast(page, print_file(f))

    def on_open(_e):
        f = state.get("file")
        if f:
            _open_path(f)

    def on_print_folder(_e):
        cls = state.get("class")
        if cls:
            _toast(page, print_folder(cls))

    def on_open_folder(_e):
        _open_path(root)

    def refresh(_e=None):
        schools = sorted((p for p in root.iterdir() if p.is_dir()))
        schools_list.controls.clear()
        classes_list.controls.clear()
        files_grid.controls.clear()
        preview_img.src = None
        file_title.value = "Select a card"
        file_meta.value = ""
        count_text.value = f"{len(schools)} school folder(s)"
        print_btn.disabled = True
        open_btn.disabled = True
        print_folder_btn.disabled = True
        for school in schools:
            n = sum(1 for c in school.iterdir() if c.is_dir())
            schools_list.controls.append(
                _folder_tile(school.name, f"{n} class(es)",
                             lambda e, s=school: pick_school(s))
            )
        page.update()

    print_btn.on_click = on_print
    open_btn.on_click = on_open
    print_folder_btn.on_click = on_print_folder
    refresh()  # initial scan

    header = ft.Row(
        spacing=12,
        controls=[
            ft.Container(
                padding=ft.Padding(top=10, bottom=10, right=10, left=10),
                bgcolor=ft.Colors.with_opacity(0.12, ft.Colors.GREEN),
                border_radius=10,
                content=ft.Icon(ft.Icons.FOLDER_OPEN, color=ft.Colors.GREEN),
            ),
            ft.Column(
                spacing=2,
                controls=[
                    ft.Text(
                        "OUTPUT FILES",
                        size=24,
                        weight=ft.FontWeight.BOLD,
                        font_family="rotten",
                    ),
                    ft.Text(
                        "Classified by the SDK — school ▸ class ▸ cards. Preview & print like a pro.",
                        size=12,
                        color=ft.Colors.GREY_400,
                    ),
                ],
            ),
            ft.Container(expand=True),
            ft.TextButton(
                icon=ft.Icons.REFRESH, content="Refresh", on_click=refresh
            ),
            ft.TextButton(
                icon=ft.Icons.FOLDER_SPECIAL, content="Open folder", on_click=on_open_folder
            ),
        ],
    )

    return ft.Container(
        expand=True,
        padding=ft.Padding(top=24, bottom=24, right=28, left=28),
        content=ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            controls=[
                header,
                ft.Divider(color=ft.Colors.GREY_800, height=28),
                ft.Row(spacing=8, controls=[path_label, ft.Container(expand=True), count_text]),
                ft.ResponsiveRow(
                    spacing=16,
                    run_spacing=16,
                    controls=[
                        # folders: school -> class
                        ft.Container(
                            col={"xs": 12, "md": 4},
                            content=ft.Column(
                                spacing=8,
                                controls=[
                                    _pane("SCHOOLS", schools_list),
                                    _pane("CLASSES", classes_list),
                                ],
                            ),
                        ),
                        # files grid + preview
                        ft.Container(
                            col={"xs": 12, "md": 8},
                            content=ft.Column(
                                spacing=10,
                                controls=[
                                    _pane("CARDS", files_scroll),
                                    ft.Container(
                                        padding=ft.Padding(top=14, bottom=14, right=16, left=16),
                                        bgcolor=ft.Colors.GREY_900,
                                        border_radius=12,
                                        border=ft.Border.all(1, ft.Colors.GREY_800),
                                        content=ft.ResponsiveRow(
                                            spacing=12,
                                            run_spacing=12,
                                            controls=[
                                                ft.Container(
                                                    col={"xs": 12, "md": 8},
                                                    alignment=ft.Alignment.CENTER,
                                                    content=preview_box,
                                                ),
                                                ft.Container(
                                                    col={"xs": 12, "md": 4},
                                                    content=ft.Column(
                                                        spacing=10,
                                                        controls=[
                                                            file_title,
                                                            file_meta,
                                                            ft.Divider(color=ft.Colors.GREY_800, height=20),
                                                            print_btn,
                                                            open_btn,
                                                            print_folder_btn,
                                                            ft.Text(
                                                                "Print sends the PDF to your default printer "
                                                                "(Windows opens the native print dialog).",
                                                                size=11,
                                                                color=ft.Colors.GREY_500,
                                                            ),
                                                        ],
                                                    ),
                                                ),
                                            ],
                                        ),
                                    ),
                                ],
                            ),
                        ),
                    ],
                ),
            ],
        ),
    )


def _pane(title: str, content) -> ft.Container:
    return ft.Container(
        padding=ft.Padding(top=10, bottom=10, right=10, left=10),
        bgcolor=ft.Colors.GREY_900,
        border_radius=12,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=ft.Column(
            spacing=6,
            controls=[
                ft.Text(title, size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_300),
                ft.Container(height=200, content=content),
            ],
        ),
    )
