"""Camera & Developer screen.

Shows the local photo endpoint (the same one the floating avatar listens on)
plus ready-to-copy code snippets for pushing photos to it — curl, Python,
JavaScript, OpenCV frames. Every photo that arrives appears in the floating
avatar *and* becomes the student photo on generated cards.
"""

import asyncio
import base64
import pathlib

import flet as ft

from cameraoverlay import (
    avatar_visible,
    color_mode,
    get_captures,
    get_endpoint_url,
    get_latest_photo,
    get_photo_count,
    set_avatar_visible,
    set_color_mode,
)

# ``{URL}`` is replaced with the live endpoint URL at build time.
_SNIPPETS = [
    (
        "curl — raw bytes",
        "bash",
        """curl -X POST {URL} \\
  -H "Content-Type: image/jpeg" \\
  --data-binary @photo.jpg""",
    ),
    (
        "curl — multipart form",
        "bash",
        """curl -X POST {URL} \\
  -F "image=@photo.jpg\"""",
    ),
    (
        "Python — requests",
        "python",
        """import requests

with open("photo.jpg", "rb") as f:
    r = requests.post("{URL}", data=f.read(),
                      headers={"Content-Type": "image/jpeg"})
print(r.json())  # {"ok": true, "saved": "..."}""",
    ),
    (
        "Python — base64 JSON",
        "python",
        """import base64, requests

b64 = base64.b64encode(open("photo.jpg", "rb").read()).decode()
r = requests.post("{URL}", json={"image": b64})
print(r.json())""",
    ),
    (
        "Python — OpenCV frame",
        "python",
        """import cv2, requests

cap = cv2.VideoCapture(0)
ok, frame = cap.read()
if ok:
    ok, jpg = cv2.imencode(".jpg", frame)
    requests.post("{URL}", data=jpg.tobytes(),
                  headers={"Content-Type": "image/jpeg"})""",
    ),
    (
        "JavaScript — fetch",
        "js",
        """// blob = an image Blob (camera / canvas / file input)
await fetch("{URL}", {
  method: "POST",
  body: blob,   // or FormData with an "image" field
});""",
    ),
]

# The one live-refresh task for the "latest photo" pane. Flet's run_task
# Future can't reliably cancel its coroutine, so a generation token makes
# stale pollers exit on their own within one cycle (rebuild / app close).
_poll_task = None
_poll_gen = 0


def stop_camera_screen():
    """Stop the camera screen's live-refresh poller (app close / rebuild)."""
    global _poll_task, _poll_gen
    _poll_gen += 1  # running pollers see the bump and exit
    if _poll_task is not None:
        try:
            _poll_task.cancel()
        except Exception:
            pass
        _poll_task = None


def _copy(page: ft.Page, text: str):
    try:
        page.clipboard = text
    except Exception:
        pass
    try:
        page.open(
            ft.SnackBar(
                content=ft.Text("Copied to clipboard", color=ft.Colors.BLACK),
                bgcolor=ft.Colors.GREEN,
                duration=1500,
            )
        )
    except Exception:
        pass


def _thumb_b64(path: pathlib.Path) -> str:
    try:
        return "data:image/png;base64," + base64.b64encode(path.read_bytes()).decode()
    except Exception:
        return ""


def _captures_row():
    """A horizontal strip of the most recent captured photos."""
    files = get_captures(10)
    if not files:
        return ft.Text(
            "No photos yet — post one to the endpoint and it will appear here.",
            size=12,
            color=ft.Colors.GREY_500,
            italic=True,
        )
    thumbs = []
    for p in files:
        thumbs.append(
            ft.Container(
                width=96,
                height=96,
                border_radius=10,
                clip_behavior=ft.ClipBehavior.HARD_EDGE,
                border=ft.Border.all(1, ft.Colors.GREY_800),
                content=ft.Image(
                    src=_thumb_b64(p),
                    width=96,
                    height=96,
                    fit=ft.BoxFit.COVER,
                ),
            )
        )
    return ft.ListView(horizontal=True, spacing=8, controls=thumbs)


def _snippet_card(page: ft.Page, title: str, lang: str, code: str) -> ft.Container:
    field = ft.TextField(
        value=code,
        read_only=True,
        multiline=True,
        min_lines=3,
        max_lines=12,
        text_size=12,
        bgcolor=ft.Colors.BLACK,
        border_radius=10,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        text_style=ft.TextStyle(
            color=ft.Colors.GREEN_300, font_family="monospace"
        ),
    )
    return ft.Container(
        col={"xs": 12, "md": 6, "xl": 4},
        padding=ft.Padding(top=14, bottom=14, right=14, left=14),
        bgcolor=ft.Colors.GREY_900,
        border_radius=12,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=ft.Column(
            spacing=8,
            controls=[
                ft.Row(
                    spacing=8,
                    controls=[
                        ft.Icon(ft.Icons.CODE, size=16, color=ft.Colors.GREEN),
                        ft.Text(title, size=14, weight=ft.FontWeight.BOLD),
                        ft.Container(expand=True),
                        ft.Text(lang.upper(), size=10, color=ft.Colors.GREY_500),
                        ft.IconButton(
                            icon=ft.Icons.CONTENT_COPY,
                            icon_size=16,
                            on_click=lambda e, c=code: _copy(page, c),
                        ),
                    ],
                ),
                field,
            ],
        ),
    )


def _settings_card(page: ft.Page) -> ft.Container:
    """Settings: floating avatar toggle + card color mode (both persisted)."""
    avatar_switch = ft.Switch(
        label="Floating camera avatar",
        value=avatar_visible(),
        active_color=ft.Colors.GREEN,
        on_change=lambda e: set_avatar_visible(page, e.control.value),
    )
    color_dd = ft.Dropdown(
        label="Card colors",
        value=color_mode(),
        width=160,
        dense=True,
        options=[
            ft.DropdownOption(key="random", text="Random per card"),
            ft.DropdownOption(key="single", text="Single default color"),
        ],
        # Selected value arrives via e.control.value (or e.data in some
        # builds) — read whichever is populated.
        on_select=lambda e: set_color_mode(
            page,
            getattr(getattr(e, "control", None), "value", None)
            or getattr(e, "data", None),
        ),
    )

    def _row(icon, title, subtitle, trailing):
        return ft.Row(
            spacing=12,
            controls=[
                ft.Container(
                    padding=ft.Padding(top=10, bottom=10, right=10, left=10),
                    bgcolor=ft.Colors.with_opacity(0.12, ft.Colors.GREEN),
                    border_radius=10,
                    content=ft.Icon(icon, color=ft.Colors.GREEN),
                ),
                ft.Column(
                    expand=True,
                    spacing=2,
                    controls=[
                        ft.Text(title, size=15, weight=ft.FontWeight.BOLD),
                        ft.Text(subtitle, size=12, color=ft.Colors.GREY_400),
                    ],
                ),
                trailing,
            ],
        )

    return ft.Container(
        padding=ft.Padding(top=16, bottom=16, right=20, left=20),
        bgcolor=ft.Colors.GREY_900,
        border_radius=14,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=ft.Column(
            spacing=14,
            controls=[
                _row(
                    ft.Icons.SETTINGS,
                    "SETTINGS",
                    "Floating avatar is hidden by default; cards can use random "
                    "colors or one default color for the whole batch.",
                    ft.Container(width=1, height=1),
                ),
                ft.Divider(color=ft.Colors.GREY_800, height=1),
                _row(
                    ft.Icons.PHOTO_CAMERA,
                    "Floating camera avatar",
                    "Drag to move, double-click to capture.",
                    avatar_switch,
                ),
                ft.Divider(color=ft.Colors.GREY_800, height=1),
                _row(
                    ft.Icons.PALETTE,
                    "Card colors",
                    "Random gives every card its own color; single uses one "
                    "default color for the whole batch.",
                    color_dd,
                ),
            ],
        ),
    )


def _endpoint_card(page: ft.Page, url: str, count_text: ft.Text) -> ft.Container:
    url_field = ft.TextField(
        value=url,
        read_only=True,
        expand=True,
        text_size=13,
        border_radius=8,
        text_style=ft.TextStyle(font_family="monospace"),
    )
    return ft.Container(
        padding=ft.Padding(top=18, bottom=18, right=20, left=20),
        bgcolor=ft.Colors.GREY_900,
        border_radius=14,
        border=ft.Border.all(1, ft.Colors.GREEN),
        content=ft.Column(
            spacing=10,
            controls=[
                ft.Row(
                    spacing=8,
                    controls=[
                        ft.Icon(ft.Icons.WIFI_TETHERING, color=ft.Colors.GREEN),
                        ft.Text(
                            "PHOTO ENDPOINT — POST photos here",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            font_family="rotten",
                        ),
                    ],
                ),
                ft.Row(
                    spacing=8,
                    controls=[
                        url_field,
                        ft.IconButton(
                            icon=ft.Icons.CONTENT_COPY,
                            on_click=lambda e: _copy(page, url),
                        ),
                    ],
                ),
                count_text,
                ft.Text(
                    "Same Wi-Fi as this PC. Every photo appears in the floating "
                    "avatar and becomes the student photo on generated cards.",
                    size=12,
                    color=ft.Colors.GREY_400,
                ),
            ],
        ),
    )


def camera_screen(page: ft.Page) -> ft.Container:
    """The Camera & Developers screen (self-contained, scrolls on its own)."""
    url = get_endpoint_url()

    count_text = ft.Text(
        f"{get_photo_count()} photo(s) received",
        size=13,
        color=ft.Colors.GREEN,
        weight=ft.FontWeight.BOLD,
    )
    latest_img = ft.Image(
        src=None,
        width=210,
        height=260,
        fit=ft.BoxFit.CONTAIN,
        border_radius=10,
    )
    latest_box = ft.Container(
        width=230,
        height=280,
        bgcolor=ft.Colors.GREY_900,
        border_radius=14,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        alignment=ft.Alignment.CENTER,
        content=latest_img,
    )

    gallery_container = ft.Container(
        height=112,
        padding=6,
        bgcolor=ft.Colors.GREY_900,
        border_radius=12,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=_captures_row(),
    )

    def refresh_gallery(e):
        gallery_container.content = _captures_row()
        page.update()

    # Live-refresh the "latest photo" pane whenever a new one arrives.
    async def _poll_latest():
        gen = _poll_gen
        last = None
        while gen == _poll_gen:
            try:
                b64 = get_latest_photo()
                if b64 and b64 != last:
                    last = b64
                    latest_img.src = f"data:image/png;base64,{b64}"
                    count_text.value = (
                        f"{get_photo_count()} photo(s) received — live from camera"
                    )
                    try:
                        page.update()
                    except Exception:
                        pass
            except Exception:
                pass
            await asyncio.sleep(2.5)

    global _poll_task
    stop_camera_screen()  # retire any previous poller (hot-reload/rebuild)
    try:
        _poll_task = page.run_task(_poll_latest)
    except Exception:
        pass

    return ft.Container(
        expand=True,
        padding=ft.Padding(top=24, bottom=24, right=28, left=28),
        content=ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            controls=[
                ft.Row(
                    spacing=12,
                    controls=[
                        ft.Container(
                            padding=ft.Padding(top=10, bottom=10, right=10, left=10),
                            bgcolor=ft.Colors.GREY_900,
                            border_radius=10,
                            border=ft.Border.all(1, ft.Colors.GREEN),
                            content=ft.Icon(
                                ft.Icons.PHOTO_CAMERA, color=ft.Colors.GREEN
                            ),
                        ),
                        ft.Column(
                            spacing=2,
                            controls=[
                                ft.Text(
                                    "CAMERA & DEVELOPERS",
                                    size=24,
                                    weight=ft.FontWeight.BOLD,
                                    font_family="rotten",
                                ),
                                ft.Text(
                                    "Push photos to the endpoint — they show in the avatar & on cards",
                                    size=12,
                                    color=ft.Colors.GREY_400,
                                ),
                            ],
                        ),
                    ],
                ),
                ft.Divider(color=ft.Colors.GREY_800, height=28),
                _endpoint_card(page, url, count_text),
                _settings_card(page),
                ft.Container(
                    padding=ft.Padding(top=18, bottom=18, right=20, left=20),
                    bgcolor=ft.Colors.GREY_900,
                    border_radius=14,
                    border=ft.Border.all(1, ft.Colors.GREY_800),
                    content=ft.ResponsiveRow(
                        spacing=16,
                        run_spacing=16,
                        controls=[
                            ft.Container(
                                col={"xs": 12, "md": 4},
                                alignment=ft.Alignment.CENTER,
                                content=latest_box,
                            ),
                            ft.Container(
                                col={"xs": 12, "md": 8},
                                content=ft.Column(
                                    spacing=12,
                                    controls=[
                                        ft.Row(
                                            controls=[
                                                ft.Icon(
                                                    ft.Icons.PHOTO_LIBRARY,
                                                    color=ft.Colors.GREEN,
                                                ),
                                                ft.Text(
                                                    "RECENT PHOTOS",
                                                    size=15,
                                                    weight=ft.FontWeight.BOLD,
                                                ),
                                                ft.Container(expand=True),
                                                ft.TextButton(
                                                    icon=ft.Icons.REFRESH,
                                                    content="Refresh",
                                                    on_click=refresh_gallery,
                                                ),
                                            ],
                                        ),
                                        gallery_container,
                                        ft.Text(
                                            "Double-click the floating avatar to "
                                            "re-save the latest photo as a capture.",
                                            size=12,
                                            color=ft.Colors.GREY_500,
                                        ),
                                    ],
                                ),
                            ),
                        ],
                    ),
                ),
                ft.Row(
                    spacing=8,
                    controls=[
                        ft.Icon(ft.Icons.TERMINAL, color=ft.Colors.GREEN),
                        ft.Text(
                            "SEND A PHOTO — COPY-PASTE CODE",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            font_family="rotten",
                        ),
                    ],
                ),
                ft.ResponsiveRow(
                    spacing=12,
                    run_spacing=12,
                    controls=[
                        _snippet_card(page, title, lang, code.replace("{URL}", url))
                        for title, lang, code in _SNIPPETS
                    ],
                ),
            ],
        ),
    )
