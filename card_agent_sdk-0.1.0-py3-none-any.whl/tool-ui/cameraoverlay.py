"""Floating circular photo-receiver avatar.

Instead of an OpenCV live stream, this widget runs a small local **HTTP
endpoint** (``POST http://<host>:<port>/photo``). The camera (or any device)
posts photos to it; each received photo appears in the circular avatar
preview **and** becomes the student photo used by the card generator.

The camera is set up to push to this endpoint by pointing its capture/HTTP
feature at the address shown under the avatar.
"""

import asyncio
import base64
import json
import os
import pathlib
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import flet as ft

# HTTP endpoint the camera pushes photos to.
_HOST = os.environ.get("CAMERA_HOST", "0.0.0.0")
_PORT = int(os.environ.get("CAMERA_PORT", "8080"))

_OUTPUT_DIR = pathlib.Path(__file__).resolve().parent.parent.parent / "output"
_CAPTURES_DIR = _OUTPUT_DIR / "captures"

_CIRCLE = 132          # avatar diameter (px)
_CAPTURE_FLASH_MS = 700
_WIDGET_W = 360         # drag-bounds width of the whole overlay widget
_WIDGET_H = 240         # drag-bounds height (circle + settings bar + hint)
_EDGE = 16              # margin from the window edge (initial + clamp)

# Singleton reference to the running overlay so app shutdown can stop the
# HTTP server without relying on page.session storage (varies across Flet
# builds). Also holds the latest received photo for the card generator.
_active_overlay = None
_latest_photo_b64 = None
_latest_photo_path = None
_latest_photo_mime = "image/png"

# The floating avatar is HIDDEN by default ("no noise"); it can be re-enabled
# from the Camera/Dev settings. The choice persists across app runs.
_SETTINGS_FILE = pathlib.Path(__file__).resolve().parent / "settings.json"


def _load_settings() -> dict:
    """Read the persisted settings dict ({} when missing/corrupt)."""
    try:
        if _SETTINGS_FILE.exists():
            data = json.loads(_SETTINGS_FILE.read_text())
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


def _save_settings(**updates):
    """Merge the given keys into settings.json (never drops other settings)."""
    data = _load_settings()
    data.update(updates)
    try:
        _SETTINGS_FILE.write_text(json.dumps(data))
    except Exception:
        pass


# Card color mode: "random" gives every card a color from the palette,
# "single" uses one default color for the whole batch (persisted).
_DEFAULT_COLOR_MODE = "random"

_settings = _load_settings()
_avatar_visible = bool(_settings.get("avatar_visible", False))
_color_mode = _settings.get("color_mode", _DEFAULT_COLOR_MODE)


def color_mode() -> str:
    """"random"" or ""single"" — how generated cards get their colors."""
    return _color_mode


def set_color_mode(page, mode: str):
    """Set the card color mode (""random"" or ""single"") and persist it."""
    global _color_mode
    _color_mode = mode if mode in ("random", "single") else _DEFAULT_COLOR_MODE
    _save_settings(color_mode=_color_mode)


def get_latest_photo() -> str | None:
    """Base64 PNG of the most recent photo received on the endpoint."""
    return _latest_photo_b64


def get_latest_photo_uri() -> str | None:
    """Full data URI of the most recent photo, e.g.
    ``data:image/jpeg;base64,...`` (None if none received yet)."""
    if not _latest_photo_b64:
        return None
    return f"data:{_latest_photo_mime};base64,{_latest_photo_b64}"


def avatar_visible() -> bool:
    """Whether the floating avatar should be shown (default: off)."""
    return _avatar_visible


def set_avatar_visible(page, visible: bool):
    """Show/hide the floating avatar and persist the choice."""
    global _avatar_visible
    _avatar_visible = bool(visible)
    _save_settings(avatar_visible=_avatar_visible)
    overlay = _active_overlay
    if overlay is not None and overlay.widget is not None:
        overlay.widget.visible = _avatar_visible
        try:
            page.update()
        except Exception:
            pass


def _lan_ip() -> str:
    """Best-effort LAN IP of this machine so cameras/devices on the same
    network can reach the photo endpoint (127.0.0.1 only works locally)."""
    try:
        import socket

        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def get_endpoint_url() -> str:
    """Full reachable URL of the photo endpoint, e.g.
    ``http://192.168.1.165:8080/photo``."""
    ov = _active_overlay
    port = ov._server.server_address[1] if ov and ov._server else _PORT
    return f"http://{_lan_ip()}:{port}/photo"


def get_photo_count() -> int:
    """Number of photos received by the endpoint so far."""
    ov = _active_overlay
    return ov._photo_count if ov else 0


def get_captures(limit: int = 12) -> list[pathlib.Path]:
    """Recent photo files saved by the endpoint, newest first."""
    if not _CAPTURES_DIR.exists():
        return []
    # Endpoint photos (photo_*) and double-tap captures (capture_*) both count.
    files = []
    for pattern in ("photo_*", "capture_*"):
        files.extend(_CAPTURES_DIR.glob(pattern))
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return files[:limit]


# --------------------------------------------------------------------------- #
# HTTP endpoint                                                               #
# --------------------------------------------------------------------------- #
class _PhotoHandler(BaseHTTPRequestHandler):
    """Serves ``POST /photo`` — raw bytes or multipart ``image`` field."""

    def log_message(self, fmt, *args):  # keep the console quiet
        pass

    def _send_ok(self, body: dict):
        data = json.dumps(body).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _send_bad(self, message: str):
        data = json.dumps({"ok": False, "error": message}).encode()
        self.send_response(400)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        """Health check: ``GET /photo`` -> {ok: true, photos: N}."""
        overlay = getattr(self.server, "overlay", None)
        self._send_ok(
            {"ok": True, "photos": overlay._photo_count if overlay else 0}
        )

    def do_POST(self):
        if self.path.split("?")[0] != "/photo":
            self._send_bad(f"unknown path {self.path}")
            return

        length = int(self.headers.get("Content-Length", 0) or 0)
        if length <= 0:
            self._send_bad("empty request body")
            return
        body = self.rfile.read(length)

        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" in content_type:
            image_bytes = _extract_multipart(body, content_type)
            if image_bytes is None:
                self._send_bad("no image field found in multipart body")
                return
        elif body.lstrip().startswith(b"{"):
            try:
                payload = json.loads(body)
            except Exception:
                self._send_bad("invalid JSON body")
                return
            raw = payload.get("image") or payload.get("image_base64") or ""
            try:
                image_bytes = base64.b64decode(raw)
            except Exception:
                self._send_bad("'image' is not valid base64")
                return
        else:
            image_bytes = body  # raw image bytes (PNG/JPEG)

        overlay = getattr(self.server, "overlay", None)
        if overlay is None:
            self._send_bad("overlay not ready")
            return
        try:
            path = overlay.ingest_photo(image_bytes)
        except Exception as ex:
            self._send_bad(f"could not store photo: {ex}")
            return
        self._send_ok({"ok": True, "saved": str(path)})


def _sniff_image_ext(image_bytes: bytes) -> str:
    """Best-effort image extension from magic bytes (PNG/JPEG/GIF/WebP)."""
    if image_bytes[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if image_bytes[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if image_bytes[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    if image_bytes[:4] == b"RIFF" and image_bytes[8:12] == b"WEBP":
        return ".webp"
    return ".img"


def _extract_multipart(body: bytes, content_type: str) -> bytes | None:
    """Pull the first file part out of a multipart/form-data body."""
    import re

    m = re.search(r'boundary="?([^";]+)"?', content_type)
    if not m:
        return None
    boundary = b"--" + m.group(1).encode()
    for part in body.split(boundary):
        if b"filename=" not in part:
            continue
        # header block ends at the first blank line
        head, _, data = part.partition(b"\r\n\r\n")
        if head and data:
            # strip trailing CRLF that belongs to the boundary
            return data.rstrip(b"\r\n")
    return None


# --------------------------------------------------------------------------- #
# Overlay widget                                                              #
# --------------------------------------------------------------------------- #
class CameraOverlay:
    """Floating circular avatar that shows photos pushed to the endpoint."""

    def __init__(self, page: ft.Page):
        self.page = page
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._photo_count = 0
        self._drag_pos = None  # (left, top) captured on pan start
        self._preview_refresh_pending = False  # coalesce preview re-renders

        # --- controls ----------------------------------------------------- #
        self.avatar_image = ft.Image(
            src=None,
            width=_CIRCLE,
            height=_CIRCLE,
            fit=ft.BoxFit.COVER,
            border_radius=_CIRCLE // 2,
        )
        self.placeholder = ft.Container(
            width=_CIRCLE,
            height=_CIRCLE,
            border_radius=_CIRCLE // 2,
            bgcolor=ft.Colors.GREY_900,
            alignment=ft.Alignment.CENTER,
            content=ft.Icon(ft.Icons.VIDEOCAM, size=40, color=ft.Colors.GREY_500),
        )
        self.status_dot = ft.Container(
            width=14,
            height=14,
            border_radius=7,
            bgcolor=ft.Colors.GREY_600,
            border=ft.Border.all(2, ft.Colors.BLACK),
        )
        self.badge = ft.Container(
            visible=False,
            padding=ft.Padding(top=4, bottom=4, right=8, left=8),
            border_radius=12,
            bgcolor=ft.Colors.GREEN,
            content=ft.Row(
                spacing=3,
                controls=[
                    ft.Icon(ft.Icons.PHOTO_CAMERA, size=12, color=ft.Colors.BLACK),
                    ft.Text("0", size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK),
                ],
            ),
        )
        self.flash = ft.Container(
            visible=False,
            width=_CIRCLE,
            height=_CIRCLE,
            border_radius=_CIRCLE // 2,
            bgcolor=ft.Colors.WHITE,
            alignment=ft.Alignment.CENTER,
            content=ft.Icon(ft.Icons.CHECK_CIRCLE, size=52, color=ft.Colors.GREEN),
        )
        self.url_field = ft.TextField(
            value=f"http://{_lan_ip()}:{_PORT}/photo",
            width=250,
            height=38,
            dense=True,
            read_only=True,
            hint_text="POST /photo endpoint",
            border_radius=8,
        )
        self.server_status = ft.Text(
            "Server starting…", size=10, color=ft.Colors.GREY_400
        )

        # --- the circular avatar ------------------------------------------ #
        self.avatar = ft.Container(
            width=_CIRCLE,
            height=_CIRCLE,
            border_radius=_CIRCLE // 2,
            border=ft.Border.all(3, ft.Colors.GREEN),
            shadow=ft.BoxShadow(
                blur_radius=18, color=ft.Colors.with_opacity(0.45, ft.Colors.GREEN)
            ),
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            content=ft.Stack(
                width=_CIRCLE,
                height=_CIRCLE,
                controls=[self.avatar_image, self.placeholder, self.flash],
            ),
        )

        # double-click re-saves the latest photo; drag moves the widget.
        self.detector = ft.GestureDetector(
            content=ft.Stack(
                controls=[
                    self.avatar,
                    ft.Container(
                        alignment=ft.Alignment.CENTER,
                        padding=ft.Padding(top=6, bottom=6, right=10, left=10),
                        content=self.status_dot,
                    ),
                    ft.Container(
                        alignment=ft.Alignment.CENTER,
                        padding=ft.Padding(top=6, bottom=6, right=6, left=6),
                        content=self.badge,
                    ),
                ],
            ),
            on_double_tap=self._on_double_tap,
            on_pan_start=self._on_pan_start,
            on_pan_update=self._on_pan_update,
        )

        self.settings_row = ft.Container(
            padding=ft.Padding(top=10, bottom=10, right=14, left=14),
            border_radius=14,
            bgcolor=ft.Colors.with_opacity(0.92, ft.Colors.GREY_900),
            border=ft.Border.all(1, ft.Colors.GREY_800),
            content=ft.Column(
                spacing=4,
                controls=[
                    ft.Row(
                        spacing=6,
                        controls=[
                            self.url_field,
                            ft.Icon(ft.Icons.COPY, size=16, color=ft.Colors.GREY_400),
                        ],
                    ),
                    self.server_status,
                ],
            ),
        )

    # ------------------------------------------------------------------ #
    # public API                                                         #
    # ------------------------------------------------------------------ #
    def build(self) -> ft.Container:
        """The floating draggable widget: avatar above the endpoint bar."""
        return ft.Container(
            width=_WIDGET_W,
            content=ft.Column(
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=8,
                controls=[
                    self.detector,
                    self.settings_row,
                    ft.Row(
                        spacing=4,
                        alignment=ft.MainAxisAlignment.CENTER,
                        controls=[
                            ft.Icon(ft.Icons.OPEN_WITH, size=12, color=ft.Colors.GREY_400),
                            ft.Text("drag to move", size=10, color=ft.Colors.GREY_400),
                        ],
                    ),
                ],
            ),
        )

    def start(self):
        """Start the HTTP endpoint in a background thread."""
        global _PORT
        if self._thread and self._thread.is_alive():
            return
        for port in range(_PORT, _PORT + 10):
            try:
                self._server = ThreadingHTTPServer((_HOST, port), _PhotoHandler)
                self._server.overlay = self
                break
            except OSError:
                continue
        if self._server is None:
            self.server_status.value = "Could not bind a port"
            try:
                self.page.update()
            except Exception:
                pass
            return
        _PORT = self._server.server_address[1]
        self.url_field.value = f"http://{_lan_ip()}:{_PORT}/photo"
        self.server_status.value = (
            f"Listening on port {_PORT} — point your camera here to push photos"
        )
        try:
            self.page.update()
        except Exception:
            pass
        self._thread = threading.Thread(
            target=self._server.serve_forever, daemon=True, name="photo-endpoint"
        )
        self._thread.start()

    def stop(self):
        """Stop the HTTP endpoint."""
        if self._server is not None:
            try:
                self._server.shutdown()
            except Exception:
                pass
            try:
                self._server.server_close()
            except Exception:
                pass
            self._server = None
        self._thread = None

    def ingest_photo(self, image_bytes: bytes) -> pathlib.Path:
        """Store a received photo, refresh the avatar, and return its path."""
        global _latest_photo_b64, _latest_photo_path, _latest_photo_mime
        _CAPTURES_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        ext = _sniff_image_ext(image_bytes)
        path = _CAPTURES_DIR / f"photo_{stamp}{ext}"
        path.write_bytes(image_bytes)

        _latest_photo_b64 = base64.b64encode(image_bytes).decode()
        _latest_photo_path = path
        _latest_photo_mime = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".gif": "image/gif",
            ".webp": "image/webp",
        }.get(ext, "image/png")
        self._photo_count += 1

        self.avatar_image.src = f"data:image/png;base64,{_latest_photo_b64}"
        self.placeholder.visible = False
        self.status_dot.bgcolor = ft.Colors.GREEN_400
        self.badge.visible = True
        self.badge.content.controls[1].value = str(self._photo_count)
        self.flash.visible = True
        self.server_status.value = f"Received {self._photo_count} photo(s) — latest → {path.name}"
        try:
            self.page.update()
        except Exception:
            pass
        try:
            self.page.run_task(self._hide_flash)
        except Exception:
            pass
        # Show the new photo on the front preview card, off the UI thread.
        # Coalesced: if a render is already queued/running, the next photo's
        # refresh is skipped and the current one will pick up the new photo.
        if not self._preview_refresh_pending:
            self._preview_refresh_pending = True
            try:
                self.page.run_task(self._refresh_preview)
            except Exception:
                self._preview_refresh_pending = False
        return path

    async def _refresh_preview(self):
        """Re-render the front card preview with the latest photo."""
        try:
            from templateview import refresh_template

            await asyncio.to_thread(refresh_template)
        finally:
            self._preview_refresh_pending = False

    # ------------------------------------------------------------------ #
    # internals                                                          #
    # ------------------------------------------------------------------ #
    def _on_double_tap(self, e):
        """Re-save the latest received photo as a capture."""
        if _latest_photo_b64 is None:
            self._toast("No photo received yet — post one to the endpoint")
            return
        try:
            path = _CAPTURES_DIR / f"capture_{datetime.now():%Y%m%d_%H%M%S}.png"
            path.write_bytes(base64.b64decode(_latest_photo_b64))
        except Exception as ex:
            self._toast(f"Capture failed: {ex}")
            return
        self.flash.visible = True
        try:
            self.page.update()
        except Exception:
            pass
        try:
            self.page.run_task(self._hide_flash)
        except Exception:
            pass
        self._toast(f"Captured → {path}")

    async def _hide_flash(self):
        await asyncio.sleep(_CAPTURE_FLASH_MS / 1000.0)
        try:
            self.flash.visible = False
            self.page.update()
        except Exception:
            pass

    def _toast(self, message: str):
        try:
            self.page.open(
                ft.SnackBar(
                    content=ft.Text(message, color=ft.Colors.BLACK),
                    bgcolor=ft.Colors.GREEN,
                    duration=2500,
                )
            )
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # drag support                                                       #
    # ------------------------------------------------------------------ #
    def _window_size(self) -> tuple[int, int]:
        try:
            w = int(self.page.window.width or 1280)
            h = int(self.page.window.height or 800)
            return w, h
        except Exception:
            return 1280, 800

    def _position_bottom_right(self, widget: ft.Container):
        win_w, win_h = self._window_size()
        widget.left = max(0, win_w - _WIDGET_W - _EDGE)
        widget.top = max(0, win_h - _WIDGET_H - _EDGE)
        try:
            self.page.update()
        except Exception:
            pass

    def _on_pan_start(self, e):
        self._drag_pos = (self.widget.left or 0, self.widget.top or 0)

    def _on_pan_update(self, e):
        if self._drag_pos is None:
            return
        dx = getattr(e, "local_delta", None)
        if dx is None:
            dx = e.global_delta
        left, top = self._drag_pos
        left += dx.x
        top += dx.y
        win_w, win_h = self._window_size()
        left = max(0, min(left, max(0, win_w - _WIDGET_W - _EDGE)))
        top = max(0, min(top, max(0, win_h - _WIDGET_H - _EDGE)))
        self._drag_pos = (left, top)
        self.widget.left = left
        self.widget.top = top
        try:
            self.page.update()
        except Exception:
            pass


def camera_overlay(page: ft.Page) -> ft.Container:
    """Create the overlay, start the endpoint, and return the widget."""
    global _active_overlay
    if _active_overlay is not None:
        _active_overlay.stop()
    overlay = CameraOverlay(page)
    _active_overlay = overlay
    overlay.start()
    overlay.widget = overlay.build()
    overlay._position_bottom_right(overlay.widget)
    overlay.widget.visible = _avatar_visible  # hidden by default
    return overlay.widget


def stop_active_overlay():
    """Stop the HTTP endpoint (called when the app closes)."""
    global _active_overlay
    if _active_overlay is not None:
        _active_overlay.stop()
        _active_overlay = None
