import flet as ft
from flet_color_pickers import BlockPicker
from templateview import template_path, template_preview_path, refresh_template

# Defaults for every placeholder the template may contain, so formatting
# never crashes with a KeyError.
_TEMPLATE_DEFAULTS = {
    "side_1_color": "#263238",
    "side_2_color": "#00897B",
    "data_qrcode": "",
    "snFontsize": "",
    "student_name": "",
    "snx": "",
    "sny": "",
    "student_class": "",
    "school_name": "",
    "school_logo": "",
    "image_base64": "",
    "name": "",
    "Class": "",
}

_SLOT_OPTIONS = [
    ft.DropdownOption(key="side_1_color", text="Side 1 Color"),
    ft.DropdownOption(key="side_2_color", text="Side 2 Color"),
]


def customize_template(e, slot):
    """Re-render the preview template with the picked color in real time."""
    try:
        values = dict(_TEMPLATE_DEFAULTS)
        values[slot] = e.data
        with open(template_path, "r") as template_read_file:
            template_content = template_read_file.read().format_map(values)
        with open(template_preview_path, "w") as template_file:
            template_file.write(template_content)

        # refresh the preview image
        refresh_template()
    except (KeyError, OSError) as error:
        print(f"template customizing failed: {error}")


def palette(default_slot="side_2_color", default_color="#00897B"):
    """A responsive color-picker card: dropdown selects which template slot
    the BlockPicker writes to."""
    state = {"slot": default_slot}

    def on_slot_change(e):
        state["slot"] = e.control.value

    return ft.Container(
        col={"xs": 12, "sm": 6, "lg": 6},
        bgcolor=ft.Colors.GREY_900,
        border_radius=4,
        padding=ft.Padding(top=20, bottom=20, right=20, left=20),
        border=ft.Border(
            top=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
            bottom=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
            right=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
            left=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
        ),
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=12,
            controls=[
                ft.Dropdown(
                    border=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
                    enable_search=True,
                    label="Customize card design",
                    label_style=ft.TextStyle(size=16, font_family="rotten"),
                    value=default_slot,
                    options=_SLOT_OPTIONS,
                    on_select=on_slot_change,
                ),
                BlockPicker(
                    color=default_color,
                    on_color_change=lambda e: customize_template(e, state["slot"]),
                ),
            ],
        ),
    )


def template_customizer():
    # The front template only exposes a {side_2_color} placeholder today, so
    # both palettes default to it to guarantee a visible real-time preview.
    # Users can still switch a palette to "Side 1 Color" via its dropdown.
    return ft.Container(
        expand=True,
        content=ft.ResponsiveRow(
            spacing=12,
            run_spacing=12,
            controls=[
                palette(default_slot="side_2_color", default_color="#00897B"),
                palette(default_slot="side_2_color", default_color="#263238"),
                palette(default_slot="side_2_color", default_color="#00897B"),
                palette(default_slot="side_2_color", default_color="#263238"),
            ],
        ),
    )
