import flet as ft
import os


def app_bar(page, refresh_callback):
    return (
        ft.Container(
            padding=ft.Padding(top=20, bottom=20, right=20, left=20),
            border=ft.Border(
                top=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
                bottom=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
                right=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
                left=ft.BorderSide(width=1, color=ft.Colors.GREY_800),
            ),
            content=ft.ResponsiveRow(
                spacing=12,
                run_spacing=12,
                controls=[
                    ft.Container(
                        col={"xs": 12, "sm": 6, "md": 4},
                        content=ft.Row(
                            controls=[
                                ft.Image(
                                    src="/home/quantumbytes/Documents/Q_PROJECTS/GEN_CARD/sdk/card_sdk/tmp/card_qrcode.png",
                                    width=48,
                                    height=48,
                                    fit=ft.BoxFit.CONTAIN,
                                ),
                                ft.Column(
                                    controls=[
                                        ft.Text(
                                            f" {os.name}",
                                            font_family="gilroy",
                                            size=16,
                                        ),
                                        ft.Text(
                                            " 192.162.1.100",
                                            font_family="gilroy",
                                            size=16,
                                        ),
                                    ]
                                ),
                            ]
                        ),
                    ),
                    ft.Container(
                        col={"xs": 12, "sm": 6, "md": 4},
                        alignment=ft.Alignment.CENTER,
                        content=ft.Text(
                            """█▀▀ ▄▀█ █▀█ █▀▄   █▀ █▀▄ █▄▀
█▄▄ █▀█ █▀▄ █▄▀   ▄█ █▄▀ █░█

Made with love py QuantumBytes""",
                            font_family="rotten",
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ),
                    ft.Container(
                        col={"xs": 12, "md": 4},
                        alignment=ft.Alignment.CENTER,
                        content=ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            wrap=True,
                            spacing=8,
                            controls=[
                                ft.TextButton(
                                    width=180,
                                    height=48,
                                    icon=ft.Icons.PLAY_ARROW,
                                    content="Preview",
                                    style=ft.ButtonStyle(
                                        text_style=ft.TextStyle(
                                            font_family="rotten"
                                        ),
                                        color=ft.Colors.GREEN,
                                        bgcolor=ft.Colors.BLACK,
                                        side=ft.BorderSide(
                                            width=1, color=ft.Colors.GREEN
                                        ),
                                    ),
                                    on_click=lambda e: refresh_callback()
                                    if refresh_callback
                                    else None,
                                ),
                                ft.TextButton(
                                    width=180,
                                    height=48,
                                    icon=ft.Icons.REFRESH,
                                    content="Refresh",
                                    style=ft.ButtonStyle(
                                        text_style=ft.TextStyle(
                                            font_family="rotten"
                                        ),
                                        color=ft.Colors.WHITE,
                                        bgcolor=ft.Colors.BLACK,
                                        side=ft.BorderSide(
                                            width=1, color=ft.Colors.WHITE
                                        ),
                                    ),
                                    on_click=lambda e: refresh_callback()
                                    if refresh_callback
                                    else None,
                                ),
                            ],
                        ),
                    ),
                ],
            ),
        ),
    )[0]
