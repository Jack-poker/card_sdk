"""Live card generation panel, linked to the local ``card_sdk`` pipeline.

When the user hits *Generate*, cards are produced one by one through the real
SDK (``generate_card``), and every finished card appears in a scrolling feed
with a counting counter and progress bar. The panel is designed to feel clean
and professional — no noise, just the essential info.
"""

import asyncio
import base64
import os
import pathlib
import sys
from io import BytesIO

# Make sure the *local* card_sdk wins over any site-packages copy.
_SDK_ROOT = pathlib.Path(__file__).resolve().parent.parent
if str(_SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(_SDK_ROOT))

import flet as ft
import svg2png_py
from svg2png_py import svg2png_py

# --- Run the SDK quietly inside the GUI (its helpers target the terminal) ---
from card_sdk import terminal_kid

terminal_kid.Tkd.inform_user = staticmethod(lambda info: None)
terminal_kid.Tkd.hello = staticmethod(lambda: None)
terminal_kid.Tkd.cleaner = staticmethod(lambda: None)
terminal_kid.Tkd.checking_task_progress = staticmethod(lambda process, current: None)

from card_sdk.card import generate_card, base_dir, output_folder
from card_sdk.base64qrcode import base64_qrcode
from card_sdk.card_agent import fetch_schools

# Latest photo pushed to the camera endpoint (POST /photo) — used as the
# student photo on generated cards and the preview card when available.
from cameraoverlay import color_mode, get_latest_photo_uri
from templateview import inject_photo

# The Kaascan students API the SDK's own CLI uses (see card_agent.multiple_cards).
_LIVE_DATA_URL = "https://api.v2.kaascan.com/admin/students"
_LIVE_API_KEY = "ykxiPah7Uc327P6sSeZ6KhXqnLwV6nxIYuVjooOInOO3ko26xgbJGz1VG"

# The single default card color used when the color setting is "single".
_DEFAULT_COLOR = "#00897B"

_db = svg2png_py.FontDatabase.system()

# Below this batch size we animate every card (scale pop + small sleep) for a
# lively feel; above it we skip the per-card delay so large batches finish fast.
_ANIMATE_THRESHOLD = 50

# How many student photos download at once during the live batch's photo phase
# (bounded to avoid flooding the photo server).
_PHOTO_CONCURRENCY = 12

# How many cards ahead the photo stream keeps downloading (twice the
# concurrency keeps a steady supply in flight while cards generate).
_PHOTO_LOOKAHEAD = _PHOTO_CONCURRENCY * 2

# Status messages cycled while the student list is being fetched.
_FETCH_STAGES = [
    "Fetching student list…",
    "Loading classes & schools…",
    "Almost there…",
]

# The SDK's per-card pipeline (photo from source -> base64 -> SVG -> PDF),
# surfaced on the UI as an animated stage indicator while cards generate.
_SDK_STAGES = [
    (ft.Icons.PHOTO_CAMERA, "Fetch photo"),
    (ft.Icons.DATA_OBJECT, "To base64"),
    (ft.Icons.CONSTRUCTION, "Build card"),
    (ft.Icons.SAVE, "Save PDF"),
]

# --------------------------------------------------------------------------- #
# Demo data (used when the live API is unreachable or the user picks Demo)     #
# --------------------------------------------------------------------------- #
_DEMO_NAMES = [
    "Aline Uwase",
    "Kevin Mugisha",
    "Chantal Niyonzima",
    "Eric Habimana",
    "Divine Uwimana",
    "Patrick Nshimiyimana",
    "Grace Mukamana",
    "Yves Niyigena",
    "Sandrine Uwase",
    "Claude Ndayisenga",
    "Joella Ingabire",
    "Moïse Nkurunziza",
]
_DEMO_CLASSES = [
    "Grade 1A",
    "Grade 2B",
    "Grade 3A",
    "Grade 4C",
    "Grade 5B",
    "Grade 6A",
]
_DEMO_COLORS = [
    "#0D47A1",
    "#B71C1C",
    "#1B5E20",
    "#4A148C",
    "#E65100",
    "#00695C",
    "#880E4F",
    "#263238",
]


def _card_color(index: int) -> str:
    """Color for card ``index`` honoring the persisted color setting.

    "random" -> a rotating palette color (one per card);
    "single" -> one default color for the whole batch.
    """
    if color_mode() == "single":
        return _DEFAULT_COLOR
    return _DEMO_COLORS[index % len(_DEMO_COLORS)]


def _avatar_png(hex_color: str) -> str:
    """A tiny solid-color PNG data URI used as a placeholder student photo."""
    from PIL import Image

    img = Image.new("RGB", (96, 96), hex_color)
    buf = BytesIO()
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def _photo_to_data_uri(url: str) -> str:
    """Download a photo and return it as a data URI for the card SVG."""
    import requests

    resp = requests.get(url, timeout=20)
    resp.raise_for_status()
    mime = (resp.headers.get("Content-Type") or "image/jpeg").split(";")[0]
    return f"data:{mime};base64," + base64.b64encode(resp.content).decode()


def _student_photo_uri(student: dict) -> str | None:
    """The student's photo as a data URI — their own photo, else the camera
    photo (the camera photo is what the preview card and feed use)."""
    b64 = student.get("image_base64") or ""
    if b64:
        return b64 if b64.startswith("data:") else f"data:image/png;base64,{b64}"
    return get_latest_photo_uri()


class _PhotoStream:
    """Just-in-time student-photo streamer.

    Downloads start immediately for the first cards and keep prefetching ahead
    while cards generate, so even a 248-card batch starts rolling in right
    away — each card only ever waits for its own (already-prefetched) photo.
    Downloads are bounded by a semaphore so the photo server is never flooded.
    """

    def __init__(self, students: list, concurrency: int = _PHOTO_CONCURRENCY):
        self.students = students
        self.sem = asyncio.Semaphore(concurrency)
        self.pending: dict[int, asyncio.Task] = {}
        self.done = [0]

    async def _ensure(self, student: dict):
        """Download one student's photo into ``image_base64`` (data URI)."""
        if student.get("image_base64") or not student.get("photo_url"):
            self.done[0] += 1
            return
        try:
            async with self.sem:
                student["image_base64"] = await asyncio.to_thread(
                    _photo_to_data_uri, student["photo_url"]
                )
        except Exception:
            student["image_base64"] = ""  # camera photo / placeholder fallback
        finally:
            self.done[0] += 1

    def start(self, lookahead: int):
        """Begin downloading the first ``lookahead`` students' photos."""
        for idx in range(min(len(self.students), lookahead)):
            self._prefetch(idx)

    def _prefetch(self, idx: int):
        if idx < len(self.students) and idx not in self.pending:
            task = asyncio.create_task(self._ensure(self.students[idx]))
            self.pending[idx] = task
            # Safe to pop twice: after wait_for() pops, this callback's pop is
            # a no-op; if the callback fired first, wait_for() gets None and
            # the photo is already in the student dict.
            task.add_done_callback(lambda _, i=idx: self.pending.pop(i, None))

    async def wait_for(self, idx: int, lookahead: int):
        """Await card ``idx``'s photo (prefetched — usually already done), then
        top the download window back up for the cards ahead."""
        task = self.pending.pop(idx, None)
        if task is not None:
            await task
        if lookahead > 0:  # never re-prefetch the card we just awaited
            self._prefetch(idx + lookahead)

    @property
    def fetched(self) -> int:
        return self.done[0]


def _demo_students(count: int) -> list:
    """Synthesized sample students — always saved under ``DEMO SCHOOL`` so
    real school folders never get polluted with sample cards."""
    students = []
    for i in range(count):
        sid = f"demo{i + 1:04d}"
        color = _card_color(i)
        students.append(
            {
                "student_id": sid,
                "student_name": _DEMO_NAMES[i % len(_DEMO_NAMES)],
                "student_class": _DEMO_CLASSES[i % len(_DEMO_CLASSES)],
                "school_name": "DEMO SCHOOL",
                # A photo pushed to the camera endpoint becomes the student
                # photo; otherwise fall back to the colored placeholder.
                "image_base64": get_latest_photo_uri() or _avatar_png(color),
                "data_qrcode": base64_qrcode({"student_id": sid}),
                "side_2_color": color,
            }
        )
    return students


def _fetch_live_metadata() -> list:
    """Fetch the student list from the Kaascan API — metadata only.

    Runs in a worker thread. The card templates have no photo slot, so the
    SDK CLI's habit of downloading + base64-encoding every student photo
    during the fetch is pure wasted time (that is what made live fetch take
    minutes and time out). A metadata-only call returns hundreds of students
    in ~2 seconds.
    """
    import requests

    resp = requests.get(
        _LIVE_DATA_URL,
        headers={"accept": "application/json", "X-API-KEY": _LIVE_API_KEY},
        timeout=45,
    )
    resp.raise_for_status()
    payload = resp.json()
    data = payload.get("data") or []
    return [d for d in data if isinstance(d, dict)]


async def _live_students(school_name: str) -> list:
    """Fetch real students from the Kaascan API (metadata only, fast).

    Cards are saved by the SDK into ``output/<school>/<class>/`` — each
    student lands in their own Class folder (real grade from the API).
    Photos are NOT downloaded here: the card template has no photo slot, so
    skipping them makes the fetch ~2s instead of minutes.
    """
    raw = await asyncio.to_thread(_fetch_live_metadata)
    students = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict) or not entry.get("student_name"):
            continue
        students.append(
            {
                "student_id": entry.get("student_id") or f"live{i + 1:04d}",
                "student_name": entry["student_name"],
                # Every card saves into its student's Class folder; guard
                # against empty grades so files never land flat in the school
                # root.
                "student_class": (entry.get("grade") or entry.get("student_class")
                                  or "Unassigned"),
                "school_name": (entry.get("school_name") or school_name) or "School",
                # No photo download (template has no photo slot). The camera
                # photo is still used as the feed/preview photo when present.
                "image_base64": "",
                "photo_url": entry.get("student_photo_url") or "",
                "data_qrcode": base64_qrcode({"student_id": entry.get("student_id") or ""}),
                "side_2_color": _card_color(i),
            }
        )
    return students


def _generate_one(student: dict) -> str:
    """Generate a single card through the real SDK pipeline."""
    return generate_card(
        image_base64=student.get("image_base64") or get_latest_photo_uri() or "",
        student_name=student["student_name"],
        student_class=student["student_class"],
        school_name=student["school_name"],
        student_id=student["student_id"],
        data_qrcode=student["data_qrcode"],
        side_2_color=student.get("side_2_color", "#00897B"),
    )


def _front_thumb(student_id: str, photo_uri: str | None = None):
    """Render the generated front template (template_x001_*.svg) to a PNG b64,
    with the student's photo spliced into the photo slot (camera photo when
    the student has none)."""
    path = os.path.join(base_dir, "templates", f"template_x001_{student_id}.svg")
    if not os.path.exists(path):
        return None
    with open(path) as f:
        svg_string = f.read()
    if photo_uri:
        svg_string = inject_photo(svg_string, photo_uri)
    try:
        png = svg2png_py.svg_to_png(
            svg_string, _db, options=svg2png_py.RenderOptions(dpi=96)
        )
        return base64.b64encode(png).decode()
    except Exception:
        return None


def _on_row_hover(e):
    """Subtle lift on hover so the feed feels alive but stays clean."""
    row = e.control
    hover = bool(e.data)
    row.border = ft.Border.all(
        1, ft.Colors.GREEN_700 if hover else ft.Colors.GREY_800
    )
    row.bgcolor = ft.Colors.GREY_800 if hover else ft.Colors.GREY_900
    try:
        row.update()
    except Exception:
        pass


def _card_row(student: dict, idx: int, total: int) -> ft.Container:
    thumb = _front_thumb(student["student_id"], _student_photo_uri(student))
    image = (
        ft.Image(
            src=thumb,
            width=160,
            height=100,
            fit=ft.BoxFit.CONTAIN,
            border_radius=10,
        )
        if thumb
        else ft.Container(
            width=160,
            height=100,
            bgcolor=ft.Colors.GREY_800,
            border_radius=10,
            alignment=ft.Alignment.CENTER,
            content=ft.Icon(ft.Icons.IMAGE_NOT_SUPPORTED, color=ft.Colors.GREY_500),
        )
    )
    return ft.Container(
        bgcolor=ft.Colors.GREY_900,
        border_radius=12,
        padding=10,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        shadow=ft.BoxShadow(
            blur_radius=12,
            spread_radius=0,
            color=ft.Colors.with_opacity(0.18, ft.Colors.BLACK),
            offset=ft.Offset(0, 4),
        ),
        animate=ft.Animation(220, ft.AnimationCurve.EASE_OUT),
        on_hover=_on_row_hover,
        content=ft.Row(
            spacing=12,
            controls=[
                image,
                ft.Column(
                    expand=True,
                    spacing=3,
                    controls=[
                        ft.Text(
                            student["student_name"],
                            size=15,
                            weight=ft.FontWeight.BOLD,
                        ),
                        ft.Text(
                            f"{student['student_class']}  •  {student['school_name']}",
                            size=12,
                            color=ft.Colors.GREY_400,
                        ),
                        ft.Row(
                            spacing=4,
                            controls=[
                                ft.Icon(
                                    ft.Icons.QR_CODE, size=12, color=ft.Colors.GREY_600
                                ),
                                ft.Text(
                                    student["student_id"],
                                    size=11,
                                    color=ft.Colors.GREY_600,
                                ),
                            ],
                        ),
                    ],
                ),
                ft.Container(
                    padding=ft.Padding(top=6, bottom=6, right=10, left=10),
                    border_radius=20,
                    bgcolor=ft.Colors.with_opacity(0.10, ft.Colors.GREEN),
                    border=ft.Border.all(
                        1, ft.Colors.with_opacity(0.35, ft.Colors.GREEN)
                    ),
                    content=ft.Row(
                        spacing=5,
                        controls=[
                            ft.Icon(
                                ft.Icons.CHECK_CIRCLE, size=14, color=ft.Colors.GREEN
                            ),
                            ft.Text(
                                f"{idx:02d}/{total:02d}",
                                size=12,
                                weight=ft.FontWeight.BOLD,
                                color=ft.Colors.GREEN,
                            ),
                        ],
                    ),
                ),
            ],
        ),
    )


def _error_row(student: dict, error: Exception) -> ft.Container:
    return ft.Container(
        bgcolor=ft.Colors.with_opacity(0.06, ft.Colors.RED),
        border_radius=12,
        padding=10,
        border=ft.Border.all(1, ft.Colors.with_opacity(0.4, ft.Colors.RED)),
        content=ft.Row(
            spacing=10,
            controls=[
                ft.Icon(ft.Icons.WARNING_AMBER, color=ft.Colors.AMBER),
                ft.Text(
                    f"{student.get('student_name', '?')} failed: {error}",
                    size=13,
                    color=ft.Colors.RED_200,
                    expand=True,
                ),
            ],
        ),
    )


def generation_panel(page: ft.Page) -> ft.Container:
    """The SDK-linked generation panel with a live scrolling feed."""

    school_dd = ft.Dropdown(
        label="School",
        value="",
        width=240,
        enable_search=True,
        options=[],
    )
    mode_dd = ft.Dropdown(
        label="Mode",
        # Production default: pull real students from the Kaascan API.
        value="live",
        width=150,
        options=[
            ft.DropdownOption(key="demo", text="Demo (local)"),
            ft.DropdownOption(key="live", text="Live (API)"),
        ],
    )
    count_dd = ft.Dropdown(
        label="Batch size",
        value="all",
        width=120,
        options=[
            # "all" = the total number of students (default). Updated to
            # "All (N)" once the real count is known.
            ft.DropdownOption(key="all", text="All"),
            *[ft.DropdownOption(key=str(n), text=str(n)) for n in (5, 10, 20, 50, 100)],
        ],
    )
    generate_btn = ft.ElevatedButton(
        "Generate cards",
        icon=ft.Icons.ROCKET_LAUNCH,
        style=ft.ButtonStyle(
            color=ft.Colors.BLACK,
            bgcolor=ft.Colors.GREEN,
            text_style=ft.TextStyle(font_family="rotten", size=15),
            side=ft.BorderSide(width=1, color=ft.Colors.GREEN),
        ),
    )

    status = ft.Text("Ready.", size=12, color=ft.Colors.GREY_400)
    counter = ft.Text(
        "0",
        size=46,
        weight=ft.FontWeight.BOLD,
        color=ft.Colors.GREEN,
        animate_scale=ft.Animation(150, ft.AnimationCurve.EASE_OUT),
    )
    total_text = ft.Text("/ 0", size=18, color=ft.Colors.GREY_400)
    done_chip_text = ft.Text(
        "0/0", size=13, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN
    )
    progress = ft.ProgressBar(
        value=0,
        bar_height=6,
        color=ft.Colors.GREEN,
        bgcolor=ft.Colors.GREY_800,
        border_radius=3,
    )
    feed = ft.ListView(auto_scroll=True, expand=True, spacing=10, padding=6)

    # Loader shown while students/photos are fetched & processed.
    fetch_status = ft.Text(_FETCH_STAGES[0], size=13, color=ft.Colors.GREY_300)
    fetch_panel = ft.Container(
        visible=False,
        padding=ft.Padding(top=24, bottom=24, right=24, left=24),
        bgcolor=ft.Colors.GREY_900,
        border_radius=14,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=12,
            controls=[
                ft.ProgressRing(
                    width=42,
                    height=42,
                    stroke_width=5,
                    color=ft.Colors.GREEN,
                ),
                ft.Text(
                    "Fetching & processing student data",
                    size=16,
                    weight=ft.FontWeight.BOLD,
                ),
                fetch_status,
                ft.ProgressBar(
                    value=None,
                    width=280,
                    height=5,
                    color=ft.Colors.GREEN,
                    bgcolor=ft.Colors.GREY_800,
                    border_radius=3,
                ),
            ],
        ),
    )

    async def _load_schools():
        try:
            schools = await fetch_schools()
            school_dd.options = [ft.DropdownOption(key=s, text=s) for s in schools]
            if schools:
                school_dd.value = schools[0]
            page.update()
        except Exception as ex:
            status.value = f"Could not load schools: {ex}"
            page.update()

    async def _run_generation(e):
        if generate_btn.disabled:
            return
        generate_btn.disabled = True
        generate_btn.bgcolor = ft.Colors.GREY_700
        feed.controls.clear()
        counter.value = "0"
        total_text.value = "/ 0"
        done_chip_text.value = "0/0"
        progress.value = 0
        status.value = "Preparing students…"
        _reset_stages()
        stage_status.value = "Waiting for students…"
        page.update()

        batch = count_dd.value or "all"
        school = school_dd.value or ""

        # Show the fetching/processing loader while students are gathered.
        fetch_panel.visible = True
        fetch_status.value = _FETCH_STAGES[0]
        page.update()
        # asyncio.create_task (not page.run_task) so cancel() actually stops
        # the status cycler — run_task's Future.cancel() does not.
        fetch_task = asyncio.create_task(_cycle_fetch_stages())

        try:
            if mode_dd.value == "live":
                students = await _live_students(school)
                if not students:
                    raise RuntimeError("no students returned from the API")
                # Default ("all") = the total number of students; an explicit
                # number caps the batch.
                count = (
                    len(students) if batch == "all" else min(int(batch), len(students))
                )
            else:
                # Demo students are synthesized, so "all" = every demo student.
                count = len(_DEMO_NAMES) if batch == "all" else int(batch)
                students = _demo_students(count)
        except Exception as ex:
            # Production behaviour: never silently substitute demo cards for
            # a failed live fetch — real output must only contain real
            # students. The user can explicitly pick Demo mode instead.
            status.value = (
                f"Live fetch failed: {ex} — switch to Demo mode to generate "
                "sample cards."
            )
            generate_btn.disabled = False
            generate_btn.bgcolor = ft.Colors.GREEN
            page.update()
            return
        finally:
            fetch_task.cancel()
            fetch_panel.visible = False
            page.update()

        students = students[:count]
        total = len(students)
        if batch == "all":
            for opt in count_dd.options:
                if opt.key == "all":
                    opt.text = f"All ({total})"
        total_text.value = f"/ {total}"
        done_chip_text.value = f"0/{total}"
        done = 0

        animate = total <= _ANIMATE_THRESHOLD

        # Live cards carry each student's photo (the template now has a photo
        # slot). Photos stream just-in-time: the first downloads start right
        # away and prefetch ahead while cards generate — so even a 248-card
        # batch starts rolling in immediately, each card waiting only for its
        # own (already-prefetched) photo.
        photo_stream = None
        if mode_dd.value == "live":
            fetch_panel.visible = True
            fetch_status.value = f"Fetching student photos 0/{total}…"
            page.update()
            photo_stream = _PhotoStream(students)
            photo_stream.start(_PHOTO_LOOKAHEAD)

        for i, student in enumerate(students, 1):
            idx = i - 1
            if photo_stream is not None:
                await photo_stream.wait_for(idx, _PHOTO_LOOKAHEAD)
                fetched = photo_stream.fetched
                fetch_status.value = f"Fetching student photos {fetched}/{total}…"
                if fetched % 5 == 0 or fetched == total:
                    try:
                        page.update()
                    except Exception:
                        pass
                if fetched >= total and fetch_panel.visible:
                    fetch_panel.visible = False
                    try:
                        page.update()
                    except Exception:
                        pass
            status.value = f"Generating {student['student_name']} ({i}/{total})…"
            if animate:
                # Walk the SDK pipeline: fetch photo -> base64 -> build -> save.
                for s in range(len(_SDK_STAGES)):
                    _style_stage(s, active=True, done=False)
                    stage_status.value = (
                        f"{student['student_name']} — {_SDK_STAGES[s][1].lower()}…"
                    )
                    page.update()
                    await asyncio.sleep(0.04)
            try:
                await asyncio.to_thread(_generate_one, student)
            except Exception as ex:
                feed.controls.append(_error_row(student, ex))
                done += 1
                counter.value = str(done)
                done_chip_text.value = f"{done}/{total}"
                progress.value = done / total
                if animate:
                    _reset_stages()
                    stage_status.value = f"{student['student_name']} — failed"
                page.update()
                if animate:
                    await asyncio.sleep(0.05)
                continue

            done += 1
            row = _card_row(student, done, total)
            feed.controls.append(row)
            counter.value = str(done)
            done_chip_text.value = f"{done}/{total}"
            progress.value = done / total
            if animate:
                _set_all_done()
                stage_status.value = f"{student['student_name']} — saved ✓"
                counter.scale = ft.Scale(1.18)
            page.update()
            if animate:
                await asyncio.sleep(0.08)
                counter.scale = ft.Scale(1.0)
                page.update()

        # Point at the classified output: output/<school>/<class>/.
        save_root = pathlib.Path(output_folder).resolve() / "output"
        if students and students[0].get("school_name"):
            save_dir = save_root / students[0]["school_name"]
        else:
            save_dir = save_root
        status.value = f"Done! {done}/{total} cards → {save_dir}/"
        if animate:
            _set_all_done()
            stage_status.value = f"Complete — {done}/{total} saved"
        generate_btn.disabled = False
        generate_btn.bgcolor = ft.Colors.GREEN
        page.update()

    async def _cycle_fetch_stages():
        """Animate the loader status text while students are being fetched."""
        stage = 0
        while True:
            fetch_status.value = _FETCH_STAGES[stage % len(_FETCH_STAGES)]
            page.update()
            stage += 1
            await asyncio.sleep(0.9)

    generate_btn.on_click = lambda e: page.run_task(_run_generation, e)
    page.run_task(_load_schools)

    # --- header ---------------------------------------------------------- #
    header = ft.Row(
        spacing=12,
        controls=[
            ft.Container(
                padding=ft.Padding(top=10, bottom=10, right=10, left=10),
                bgcolor=ft.Colors.with_opacity(0.12, ft.Colors.GREEN),
                border_radius=10,
                content=ft.Icon(ft.Icons.AUTO_AWESOME, color=ft.Colors.GREEN),
            ),
            ft.Column(
                spacing=2,
                controls=[
                    ft.Text(
                        "AI CARD GENERATOR",
                        size=22,
                        weight=ft.FontWeight.BOLD,
                        font_family="rotten",
                    ),
                    ft.Text(
                        "Batch cards through the local Kaascan SDK — watch them roll in live.",
                        size=12,
                        color=ft.Colors.GREY_400,
                    ),
                ],
            ),
            ft.Container(expand=True),
            ft.Container(
                padding=ft.Padding(top=6, bottom=6, right=10, left=10),
                border_radius=20,
                bgcolor=ft.Colors.with_opacity(0.10, ft.Colors.GREEN),
                border=ft.Border.all(
                    1, ft.Colors.with_opacity(0.35, ft.Colors.GREEN)
                ),
                content=ft.Row(
                    spacing=6,
                    controls=[
                        ft.Container(
                            width=8,
                            height=8,
                            border_radius=4,
                            bgcolor=ft.Colors.GREEN_400,
                        ),
                        ft.Text(
                            "SDK LINKED",
                            size=10,
                            weight=ft.FontWeight.BOLD,
                            color=ft.Colors.GREEN_300,
                        ),
                    ],
                ),
            ),
        ],
    )

    # --- controls card --------------------------------------------------- #
    controls_card = ft.Container(
        padding=ft.Padding(top=16, bottom=16, right=16, left=16),
        bgcolor=ft.Colors.GREY_900,
        border_radius=14,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=ft.ResponsiveRow(
            spacing=10,
            run_spacing=10,
            controls=[
                ft.Container(col={"xs": 12, "sm": 6, "md": 4}, content=mode_dd),
                ft.Container(col={"xs": 12, "sm": 6, "md": 4}, content=school_dd),
                ft.Container(col={"xs": 12, "sm": 6, "md": 2}, content=count_dd),
                ft.Container(
                    col={"xs": 12, "sm": 6, "md": 2},
                    alignment=ft.Alignment.CENTER,
                    content=generate_btn,
                ),
            ],
        ),
    )

    # --- stats strip ----------------------------------------------------- #
    stats_card = ft.Container(
        padding=ft.Padding(top=16, bottom=16, right=18, left=18),
        bgcolor=ft.Colors.GREY_900,
        border_radius=14,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=ft.Row(
            spacing=16,
            controls=[
                ft.Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=0,
                    controls=[
                        ft.Row(
                            spacing=4,
                            controls=[counter, total_text],
                        ),
                        ft.Text(
                            "CARDS GENERATED",
                            size=10,
                            color=ft.Colors.GREY_500,
                        ),
                    ],
                ),
                ft.Container(width=1, height=52, bgcolor=ft.Colors.GREY_800),
                ft.Column(
                    expand=True,
                    spacing=8,
                    controls=[progress, status],
                ),
                ft.Container(
                    padding=ft.Padding(top=8, bottom=8, right=12, left=12),
                    border_radius=20,
                    bgcolor=ft.Colors.with_opacity(0.10, ft.Colors.GREEN),
                    border=ft.Border.all(
                        1, ft.Colors.with_opacity(0.35, ft.Colors.GREEN)
                    ),
                    content=ft.Row(
                        spacing=6,
                        controls=[
                            ft.Icon(
                                ft.Icons.CHECK_CIRCLE, size=16, color=ft.Colors.GREEN
                            ),
                            done_chip_text,
                        ],
                    ),
                ),
            ],
        ),
    )

    # --- SDK pipeline indicator ----------------------------------------- #
    stage_status = ft.Text("Idle", size=12, color=ft.Colors.GREY_400)
    stage_chips = []

    def _style_stage(index: int, active: bool, done: bool):
        icon, label = _SDK_STAGES[index]
        chip = stage_chips[index]
        if done:
            color = ft.Colors.GREEN
            bg = ft.Colors.with_opacity(0.10, ft.Colors.GREEN)
        elif active:
            color = ft.Colors.BLACK
            bg = ft.Colors.GREEN
        else:
            color = ft.Colors.GREY_400
            bg = ft.Colors.GREY_800
        chip.bgcolor = bg
        chip.border = ft.Border.all(
            1, ft.Colors.GREEN if (active or done) else ft.Colors.GREY_700
        )
        chip.content.controls[0] = ft.Icon(
            ft.Icons.CHECK_CIRCLE if done else icon, size=14, color=color
        )
        chip.content.controls[1].color = color

    for icon, label in _SDK_STAGES:
        stage_chips.append(
            ft.Container(
                padding=ft.Padding(top=6, bottom=6, right=10, left=10),
                border_radius=20,
                bgcolor=ft.Colors.GREY_800,
                border=ft.Border.all(1, ft.Colors.GREY_700),
                content=ft.Row(
                    spacing=5,
                    controls=[
                        ft.Icon(icon, size=14, color=ft.Colors.GREY_400),
                        ft.Text(label, size=11, color=ft.Colors.GREY_400),
                    ],
                ),
            )
        )

    def _reset_stages():
        for i in range(len(stage_chips)):
            _style_stage(i, active=False, done=False)

    def _set_all_done():
        for i in range(len(stage_chips)):
            _style_stage(i, active=False, done=True)

    pipeline_card = ft.Container(
        padding=ft.Padding(top=10, bottom=10, right=12, left=12),
        bgcolor=ft.Colors.GREY_900,
        border_radius=12,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=ft.Row(
            spacing=8,
            controls=[
                ft.Text("SDK", size=10, weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_300),
                ft.Text("PIPELINE", size=10, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_500),
                *stage_chips,
                ft.Container(expand=True),
                stage_status,
            ],
        ),
    )

    # --- live feed ------------------------------------------------------- #
    feed_card = ft.Container(
        height=400,
        padding=ft.Padding(top=12, bottom=12, right=12, left=12),
        bgcolor=ft.Colors.GREY_900,
        border_radius=14,
        border=ft.Border.all(1, ft.Colors.GREY_800),
        content=feed,
    )

    return ft.Container(
        content=ft.Column(
            spacing=16,
            controls=[header, controls_card, stats_card, pipeline_card, fetch_panel, feed_card],
        ),
    )
