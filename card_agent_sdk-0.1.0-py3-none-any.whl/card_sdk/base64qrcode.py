import qrcode
from qrcode.util import QRData, MODE_8BIT_BYTE
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import (
    RoundedModuleDrawer, 
    CircleModuleDrawer,
    GappedSquareModuleDrawer,
    VerticalBarsDrawer,
    HorizontalBarsDrawer,
    SquareModuleDrawer
)
from qrcode.image.styles.colormasks import (
    SolidFillColorMask,
    RadialGradiantColorMask,
    SquareGradiantColorMask,
    HorizontalGradiantColorMask,
    VerticalGradiantColorMask
)

import base64
from io import BytesIO
import pathlib

from cool_qrcode import make_cool_qrcode
from PIL import Image

base_dir = pathlib.Path(__file__).parent







def base64_qrcode(qrcode_content: dict,selected_style = "4",front_color = "aad400ff") -> str:

  qr_styles = {
    "1": {
        "name": "Rounded Navy",
        "drawer": RoundedModuleDrawer(),
        "color": SolidFillColorMask(
            front_color=tuple(int(f"{front_color}"[i:i+2], 16) for i in (0, 2, 4, 6)),
            back_color=(255, 255, 255)
        ),
        "description": "Rounded squares, dark navy. Clean."
    },
    "2": {
        "name": "Ocean Circles",
        "drawer": CircleModuleDrawer(),
        "color": SolidFillColorMask(
            front_color=tuple(int(f"{front_color}"[i:i+2], 16) for i in (0, 2, 4, 6)),
            back_color=(255, 255, 255)
        ),
        "description": "Circular dots, ocean blue. Modern."
    },
    "3": {
        "name": "Forest Green",
        "drawer": GappedSquareModuleDrawer(),
        "color": SolidFillColorMask(
            front_color=tuple(int(f"{front_color}"[i:i+2], 16) for i in (0, 2, 4, 6)),
            back_color=(240, 255, 240)
        ),
        "description": "Gapped squares, green. Organic."
    },
    "4": {
        "name": "Sunset Warm",
        "drawer": RoundedModuleDrawer(),
        "color": SolidFillColorMask(
            front_color=tuple(int(f"{front_color}"[i:i+2], 16) for i in (0, 2, 4, 6)),
            back_color=(255, 245, 240)
        ),
        "description": "Rounded, warm orange. Energetic."
    },
    "5": {
        "name": "Minimal Bars",
        "drawer": VerticalBarsDrawer(),
        "color": SolidFillColorMask(
            front_color=tuple(int(f"{front_color}"[i:i+2], 16) for i in (0, 2, 4, 6)),
            back_color=(255, 255, 255)
        ),
        "description": "Vertical bars, pure B&W. Minimalist."
    },
    "6": {
        "name": "Luxury Gold",
        "drawer": RoundedModuleDrawer(),
        "color": SolidFillColorMask(
            front_color=(180, 140, 50),
            back_color=(250, 245, 235)
        ),
        "description": "Rounded gold on cream. Premium."
    },
    "7": {
        "name": "Qaad Purple",
        "drawer": CircleModuleDrawer(),
        "color": SolidFillColorMask(
            front_color=tuple(int(f"{front_color}"[i:i+2], 16) for i in (0, 2, 4, 6)),
            back_color=(255, 255, 255)
        ),
        "description": "Circular dots, Qaad purple. Brand."
    },
}

  qr =  qrcode.QRCode(
    version=1,
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10,
    border=4,
    )

  qr.add_data(qrcode_content)
  qr.make(fit=True)


  for key, style in qr_styles.items():
    # print(f"  [{key}] {style['name']} - {style['description']}")
    pass

  SELECTED = selected_style # <--- CHANGE THIS to try different styles (1-7)
  style = qr_styles[SELECTED]
  
  img = qr.make_image(
    image_factory=StyledPilImage,
    module_drawer=style["drawer"],
    color_mask=style["color"],
    embeded_image=None,  # Add logo later if needed
)
  img.save(f"{base_dir}/tmp/card_qrcode.png")
     
  img = Image.open(f"{base_dir}/tmp/card_qrcode.png")

  buffer = BytesIO()
  img.save(buffer, format="PNG")  # Save as PNG to buffer
  img_bytes = buffer.getvalue()   # Get the PNG-encoded bytes

  base64Qrcode = f"data:image/png;base64,{base64.b64encode(img_bytes).decode('utf-8')}"
  return base64Qrcode




 