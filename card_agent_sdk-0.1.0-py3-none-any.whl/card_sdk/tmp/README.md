Runtime-generated directory. Contents are regenerated at runtime; not committed.
