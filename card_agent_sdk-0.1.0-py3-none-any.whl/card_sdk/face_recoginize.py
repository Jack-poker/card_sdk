# import face_recognition
# from face_recognition import face_locations
# import face_recognition_models
# import rembg


# class FaceRecognize:
#     def __init__(self, face_image_path: bytes):
#         self.face_image_path = face_image_path

#     def face_recognition(self):
#         image = face_locations(self.face_image_path)


# face: FaceRecognize = FaceRecognize(face_image="/home/quantumbytes/Documents/Q_PROJECTS/GEN_CARD/sdk/face_reco/test/1.jpg")
# face_locations = face.face_recognition()
