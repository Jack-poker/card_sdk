import re
import time

from color_cli import color_text
import requests
import asyncio
import aiohttp
import pathlib



base_dir = pathlib.Path(__file__).parent

def check_file_corrupt(template_content: str) -> bool:

    is_corrupt = False
    
    check_contains = ["<svg>","</svg>","xml"]

    for key_checks in check_contains: 
        # if patterns missing the template is corrupt
        result = (re.search(key_checks,template_content) == None) != True
        is_corrupt = (re.search(key_checks,template_content) == None)
            
        
    return is_corrupt

 


async def save_template(front_temple: str,back_template: str) -> bool:
    with open(f"{base_dir}/templates/update/cache/front.card.kaascan.update","w+") as front_card_file:
        front_card_file.write(front_temple)


    with open(f"{base_dir}/templates/update/cache/back.card.kaascan.update","w+") as back_card_file:
        back_card_file.write(back_template)
    
    return True


async def get_template(cloud_url: str) -> str:
    async with aiohttp.ClientSession() as session:

        svg_templates = []

        result = await session.get(cloud_url)
        svg_template = await result.content.read()

        if check_file_corrupt(svg_template.decode("utf-8")):
            print(color_text("[!] Template file corrupt | Please reach out to fix up.",color="red"))
            exit()


        return svg_template.decode("utf-8")

                


async def update_template() -> dict:
    try:
        cloud_urls = {
            "card_front_template_url": "https://admin.kaascan.com/assets/3c4a1121-aa20-4e71-81e6-0d76293478c9?download=",
            "card_back_template_url": "https://admin.kaascan.com/assets/5e8f1f19-fc65-4ab4-8522-3b0a6fcfb849?download="
        }

        await save_template( front_temple = await get_template(cloud_urls["card_front_template_url"]),
                             back_template = await get_template(cloud_urls["card_back_template_url"]) )
        

        print(color_text(f"[*] template up to date","green"))
                

            

                



                

       
            




    except Exception as update_error:
        exit()
        print(f'[-] updating failed please check: {update_error}')

if __name__ == "__main__":
   asyncio.run(update_template())
   
