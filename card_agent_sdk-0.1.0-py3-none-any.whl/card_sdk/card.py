import asyncio
import base64
from datetime import datetime
from io import BytesIO
import pathlib
import os
import re
import aiofiles
import aiohttp
from color_cli import color_text
from requests_cache import Optional
import svg2pdf_py
import requests
from pydantic import BaseModel
import json
import pymupdf
from cool_qrcode import make_cool_qrcode
from PIL import Image
from card_sdk.base64qrcode import base64_qrcode
from jload import jsave
import ui
from super_progress_bar import Progress
from aiocache import cached
from .cardgen.cardgen import card

progress = Progress(
    min_value=0,
    max_value=100,
    unit="items",
    colors=[(0, 0, 0), (255, 255, 0), (255, 255, 0), (0, 0, 0)],
    single_color=False,
)


base_dir = pathlib.Path(__file__).parent
output_folder = pathlib.Path(__file__).parent.parent
# Load fonts
svg = svg2pdf_py.FontDatabase()
svg.load_font_file(f"{base_dir}/fonts/minigap.otf")
svg.load_font_file(f"{base_dir}/fonts/FHLecturis-Bold.ttf")
# Gilroy fonts used by BLUE_TOPBAR_CARD template — add font files to card_sdk/fonts/
# NOTE: svg2pdf_py resolves font-family by a font's *internal* family name, not the
# file name. Known internal names: "Minigap" (minigap.otf), "FH Lecturis"
# (FHLecturis-Bold.ttf), "Gilroy" (Gilroy-*.ttf).
_loaded_font_names = {"Minigap", "FH Lecturis"}
for _gilroy in ("Gilroy-UltraBold.ttf", "Gilroy-Light.ttf"):
    try:
        svg.load_font_file(f"{base_dir}/fonts/{_gilroy}")
        _loaded_font_names.add("Gilroy")
    except Exception:
        pass


def _sanitize_font_families(svg_text: str) -> str:
    """Replace font-family references that svg2pdf can't resolve.

    When ``svg2pdf_py`` encounters a ``font-family`` name not loaded in the
    ``FontDatabase`` it silently drops **all** text from the entire SVG.
    This function swaps out any unrecognised font names for a known fallback so
    text is never lost.

    The fallback is weight-aware: bold/Ultra-Bold text maps to the loaded bold
    face (``FH Lecturis``) and normal text to ``Minigap``, otherwise bold styling
    would be silently flattened to a regular weight.
    """
    _REGULAR = "Minigap"
    _BOLD = "FH Lecturis"
    _BOLD_HINTS = ("bold", "ultra-bold", "extrabold", "800", "700", "900")
    _RE_FONT_FAMILY = re.compile(
        r'''font-family\s*:\s*(?:'([^']+)'|"([^"]+)"|([^\s;"'}]+))'''
    )
    _RE_FONT_WEIGHT = re.compile(
        r'''font-weight\s*:\s*([^;]+)'''
    )
    _RE_INKSCAPE_SPEC = re.compile(
        r"""-inkscape-font-specification\s*:\s*'([^']+)'"""
    )

    def _is_bold(style_slot: str, family: str) -> bool:
        hint = _RE_FONT_WEIGHT.search(style_slot)
        weight = hint.group(1).strip().lower() if hint else ""
        if weight and (weight.isdigit() and int(weight) >= 700) or weight in ("bold", "bolder"):
            return True
        low_fam = family.lower()
        return any(h in low_fam or h in weight for h in _BOLD_HINTS)

    def _fallback(name: str) -> str:
        return _BOLD if _is_bold(style_slot_cache.get(name, ""), name) else _REGULAR

    # First pass: rewrite font-family for any family that isn't loaded.
    style_slot_cache = {}

    def _replace_family(m):
        name = m.group(1) or m.group(2) or m.group(3)
        name = name.strip()
        if name in _loaded_font_names:
            return m.group(0)
        # Look backwards from the match to find the enclosing style="..." slot
        # so we can honour font-weight.
        start = max(0, m.start() - 400)
        prev = svg_text[start:m.start()]
        style_slot = prev.rsplit('style="', 1)[-1] if 'style="' in prev else ""
        style_slot_cache[name] = style_slot
        return f"font-family:{_fallback(name)}"

    svg_text = _RE_FONT_FAMILY.sub(_replace_family, svg_text)

    def _replace_ink(m):
        spec = m.group(1)
        family = spec.split(",")[0].strip()
        if family in _loaded_font_names:
            return m.group(0)
        bold = _is_bold(style_slot_cache.get(family, ""), family) or any(
            b in spec.lower() for b in _BOLD_HINTS
        )
        face = _BOLD if bold else _REGULAR
        style = "Bold" if bold else "Normal"
        return f"-inkscape-font-specification:'{face}, {style}'"

    svg_text = _RE_INKSCAPE_SPEC.sub(_replace_ink, svg_text)
    return svg_text

# defined just variables for the student data


class Student(BaseModel):
    photo: str
    name: str
    Class: str
    school_name: str
    data_qrcode: str = ""  # optional: empty dict "{}" when the card uses a barcode instead
    student_id: str
    template_name: str
    
    # Additional card variables
    stamp: Optional[str] = None  # Base64 encoded stamp image
    signature: Optional[str] = None  # Base64 encoded signature image
    barcode: Optional[str] = None  # Base64 encoded barcode image
    school_logo: Optional[str] = None  # Base64 encoded school logo
    side_2_color: str = "#00897B"  # Card back color
    snFontsize: float = 2.4932  # Student name font size
    snx: float = -10.523738  # Student name x axis position
    sny: float = -0.8769781  # Student name y axis position


class CardConfig(BaseModel):
    """Structured configuration for card generation.
    
    This class provides a clean API for specifying all card variables,
    including stamps, signatures, barcodes, and other customization options.
    """
    # Student data
    student_name: str
    student_class: str
    school_name: str
    student_id: str
    photo: str  # Base64 encoded student photo
    
    # QR code data
    data_qrcode: str = ""  # optional: empty dict "{}" when the card uses a barcode instead
    
    # Template selection
    template_name: str
    
    # Branding elements
    school_logo: Optional[str] = ""  # Base64 encoded school logo
    stamp: Optional[str] = ""  # Base64 encoded stamp image
    signature: Optional[str] = ""  # Base64 encoded signature image
    barcode: Optional[str] = ""  # Base64 encoded barcode image
    
    # Card styling
    side_2_color: str = "#00897B"  # Card back color
    
    # Typography settings
    snFontsize: float = 2.4932  # Student name font size
    snx: float = -10.523738  # Student name x axis position
    sny: float = -0.8769781  # Student name y axis position
    
    def to_student(self) -> Student:
        """Convert CardConfig to Student model for backward compatibility."""
        return Student(
            photo=self.photo,
            name=self.student_name,
            Class=self.student_class,
            school_name=self.school_name,
            data_qrcode=self.data_qrcode,
            student_id=self.student_id,
            template_name=self.template_name,
            stamp=self.stamp,
            signature=self.signature,
            barcode=self.barcode,
            school_logo=self.school_logo,
            side_2_color=self.side_2_color,
            snFontsize=self.snFontsize,
            snx=self.snx,
            sny=self.sny
        )
    
    def generate_card_content(self) -> dict:
        """Generate card content using this configuration."""
        return generate_card(
            template_name=self.template_name,
            image_base64=self.photo,
            student_name=self.student_name,
            student_class=self.student_class,
            school_name=self.school_name,
            student_id=self.student_id,
            data_qrcode=self.data_qrcode,
            side_2_color=self.side_2_color,
            school_logo=self.school_logo,
            stamp_base64=self.stamp,
            student_barcode=self.barcode,
            signature_base64=self.signature,
            snFontsize=self.snFontsize,
            snx=self.snx,
            sny=self.sny
        )


def image_file_to_base64(file_path: str) -> str:
    """Convert an image file to base64 string.
    
    Args:
        file_path: Path to the image file (PNG, JPG, etc.)
        
    Returns:
        Base64 encoded string of the image
    """
    with open(file_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')


def image_url_to_base64(url: str) -> str:
    """Convert an image URL to base64 string.
    
    Args:
        url: URL of the image
        
    Returns:
        Base64 encoded string of the image
    """
    response = requests.get(url)
    return base64.b64encode(response.content).decode('utf-8')


def resize_image_base64(image_base64: str, max_width: int = 100, max_height: int = 100) -> str:
    """Resize a base64 encoded image to fit within specified dimensions.
    
    Args:
        image_base64: Base64 encoded image string
        max_width: Maximum width in pixels
        max_height: Maximum height in pixels
        
    Returns:
        Resized base64 encoded image string
    """
    image_data = base64.b64decode(image_base64)
    image = Image.open(BytesIO(image_data))
    
    # Calculate new dimensions while maintaining aspect ratio
    ratio = min(max_width / image.width, max_height / image.height)
    new_width = int(image.width * ratio)
    new_height = int(image.height * ratio)
    
    # Resize image
    resized_image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
    
    # Convert back to base64
    buffer = BytesIO()
    resized_image.save(buffer, format=image.format or 'PNG')
    return base64.b64encode(buffer.getvalue()).decode('utf-8')


def save_card(card_content: dict, card_id: str, class_folder: str, school_name: str):

    if not os.path.exists(
        f"{pathlib.Path(__file__).parent.parent}/output/{school_name}"
    ):
        school_folder = (
            pathlib.Path(__file__).parent.parent / "output" / f"{school_name}"
        )
        school_folder.mkdir(exist_ok=True)

    card_templates = card_content
    front_card = _sanitize_font_families(card_templates["front"]["card"])
    back_card = _sanitize_font_families(card_templates["back"]["card"])

    output_dir = pathlib.Path(output_folder) / "output" / school_name / class_folder
    output_dir.mkdir(parents=True, exist_ok=True)
    output_pdf = output_dir / f"final_student_card_{card_id}.pdf"

    # Render both faces straight from the in-memory SVG strings — no wasted
    # disk write + re-read of every card's template files.
    try:
        pdf_pages = svg2pdf_py.svg_pages_to_pdfs([front_card, back_card], svg)
    except Exception as error:
        print(f":: failed converting svg of card_id: {card_id} to pdf: {error}")
        pdf_pages = []

    if not pdf_pages:
        print(f":: warning: svg-to-pdf produced no pages for card_id: {card_id}")

    doc = pymupdf.open()
    for pdf_bytes in pdf_pages:
        part = pymupdf.open("pdf", pdf_bytes)
        doc.insert_pdf(part)
        part.close()

    # garbage=0 / deflate=False: each per-card PDF is tiny (2 pages). The heavy
    # GC + stream re-compression only pays off on the final merged document, so
    # skip it here to avoid a full PDF rebuild per card.
    doc.save(str(output_pdf), garbage=0, deflate=False)
    doc.close()


def _decode_urlencoded_placeholders(svg_text: str) -> str:
    """Decode Inkscape's URL-encoded curly braces back to normal format placeholders.

    Inkscape encodes ``{`` as ``%7B`` and ``}`` as ``%7D`` inside ``xlink:href``
    attributes, which prevents Python's ``str.format()`` from recognising them.
    This helper reverses that encoding so template substitution works correctly.
    """
    return svg_text.replace("%7B", "{").replace("%7D", "}")


def _safe_format(svg_text: str, fmt_args: dict) -> str:
    """Substitute ``{name}`` placeholders for the supplied keys, leaving any
    other ``{...}`` group intact.

    Templates may legitimately contain CSS rules such as ``{ color:#dedede; }``
    or stray braces. ``str.format()`` would mis-parse those as field names and
    raise ``KeyError`` (e.g. ``' color'``), crashing card generation. A regex
    only substitutes names we actually know, so stray braces survive untouched.
    """
    def sub(m):
        prefix = m.group(1) or ""
        name = m.group(2)
        if name in fmt_args:
            value = str(fmt_args[name])
            # Inkscape-authored templates often anchor images with a "..\\" path
            # prefix (xlink:href="../{photo}"). If the injected value is an
            # absolute URI, that prefix corrupts it ("../data:..." never loads),
            # so drop it — otherwise the image silently vanishes from the card.
            is_uri = value.startswith("data:") or value.startswith("http://") or value.startswith("https://")
            if is_uri and prefix:
                return value
            return prefix + value
        return m.group(0)  # unknown/ambiguous group: leave as-is

    return re.sub(r"(\.\./|\./)?\{([A-Za-z_][\w]*)\}", sub, svg_text)


def _fmt(value) -> str:
    """Never let a None reach the SVG: empty string instead."""
    return "" if value is None else str(value)


def _img_href(value):
    """Only safe image references reach xlink:href; anything else renders invisibly.

    Accepts data-URIs, http(s) URLs, and bare base64 strings (which are
    promoted to ``data:image/png;base64,`` so images are never silently
    dropped).
    """
    if not isinstance(value, str) or not value.strip():
        return ""
    value = value.strip()
    if value.startswith("data:image") or value.startswith("http"):
        return value
    # bare base64 → data URI (default to PNG; harmless for most stamps/logos)
    return f"data:image/png;base64,{value}"


def generate_card(
    template_name: str,
    image_base64: str,
    student_name: str,
    student_class: str,
    school_name: str,
    student_id: str,
    # qrcode
    data_qrcode: str = "",  # optional: leave empty dict "{}" when the card uses a barcode instead
    side_2_color: str = "#00897B",
    # branding
    school_logo: str = "",
    stamp_base64: str = "",
    student_barcode: str = "",
    signature_base64: str = "",
    # styling
    snFontsize=2.4932,  # student name font size
    snx=-10.523738,  # student name x axis position
    sny=-0.8769781,  # student name y axis position
) -> str:  # the card content is a string so it has a string return type declared

    fmt_args = {
        "color": "#0d0000",
        "academic_year": f"ACADEMIC YEAR {datetime.now().year}",
        "school_subtitle": "subtitle here",
        "snFontsize": _fmt(snFontsize),
        "name": _fmt(student_name),
        "student_names": _fmt(student_name),
        "snx": _fmt(snx),
        "sny": _fmt(sny),
        "Class": _fmt(student_class),
        "student_class": _fmt(student_class),
        "school_name": _fmt(school_name),
        "student_id": _fmt(student_id),
        "school_logo": _img_href(school_logo),
        "image_base64": _img_href(image_base64),
        "student_photo": _img_href(image_base64),
        "side_2_color": _fmt(side_2_color) or "#00897B",
        "data_qrcode": _img_href(data_qrcode),
        "stamp_base64": _img_href(stamp_base64),
        "student_barcode": _img_href(student_barcode),
        "signature_base64": _img_href(signature_base64),
    }

    with open(f"{base_dir}/templates/templates_base/{template_name}/front.card.kaascan", "r", encoding="utf-8") as f:
        front = _safe_format(_decode_urlencoded_placeholders(f.read()), fmt_args)

    with open(f"{base_dir}/templates/templates_base/{template_name}/back.card.kaascan", "r", encoding="utf-8") as f:
        back = _safe_format(_decode_urlencoded_placeholders(f.read()), fmt_args)

    card_content = {"front": {"card": front}, "back": {"card": back}}

    # Report any required element that was not supplied so it doesn't silently
    # vanish from the card (stamp / signature / barcode / logo / QR / photo).
    # ``data_qrcode`` is an alternative to ``student_barcode``: a card that
    # carries a barcode does not need QR data, so skip that check when a
    # barcode is present.
    _missing = [
        name
        for name, raw in (
            ("stamp_base64", stamp_base64),
            ("signature_base64", signature_base64),
            ("student_barcode", student_barcode),
            ("school_logo", school_logo),
            ("data_qrcode", data_qrcode),
            ("image_base64", image_base64),
        )
        if not (raw and str(raw).strip())
        and not (name == "data_qrcode" and student_barcode and str(student_barcode).strip())
    ]
    if _missing:
        report_missing(
            card_id=student_id,
            school_name=school_name,
            student_class=student_class,
            missing=_missing,
        )

    if not os.path.exists(
        f"{pathlib.Path(__file__).parent.parent}/output/{school_name}/{student_class}"
    ):
        school_folder = (
            pathlib.Path(__file__).parent.parent
            / "output"
            / school_name
            / student_class
        )
        # parents=True so a brand-new school folder is created too — cards
        # always land inside the student's Class folder.
        school_folder.mkdir(parents=True, exist_ok=True)

    save_card(
        card_content,
        card_id=student_id,
        class_folder=student_class,
        school_name=school_name,
    )

    from card_sdk.terminal_kid import Tkd

    Tkd.inform_user(f"[ok] {student_id[:5]} card saved ::")
    Tkd.hello()
    print(color_text(text="(saving cards) Please wait...", color="blue"))

    return f"(completed output folder) : {base_dir}/output/"


_REPORT_CTR = 0
_report_ctr_initialized = False
_report_lock: object = None


def _report_path() -> str:
    return f"{base_dir}/report/cards_report.json"


def _init_report_counter() -> int:
    """Return the number of records already in cards_report.json (O(1) read)."""
    global _REPORT_CTR, _report_ctr_initialized, _report_lock
    import threading
    if _report_lock is None:
        _report_lock = threading.Lock()
    if not _report_ctr_initialized:
        _report_ctr_initialized = True
        try:
            import json as _json
            with open(_report_path(), "r", encoding="utf-8") as fh:
                _REPORT_CTR = len(_json.load(fh))
        except Exception:
            _REPORT_CTR = 0
    return _REPORT_CTR


async def cards_report(user_id: str, status: str) -> any:
    """Record a card event *cheaply*.

    The old implementation called jsave(append=True) which re-parsed and
    rewrote the whole JSON array on every single card — O(n²) disk churn that
    can turn a large batch into minutes. We append one JSON line (JSONL) per
    event and keep an in-memory counter for count_cards(), so a batch of N
    cards costs O(1) file I/O each instead of O(n).
    """
    global _REPORT_CTR
    if _report_lock is None:
        _init_report_counter()
    try:
        with _report_lock:
            with open(_report_path() + "l", "a", encoding="utf-8") as fh:
                fh.write(
                    json.dumps(
                        {"user_id": user_id, "task": "generate_card", "status": status}
                    )
                    + "\n"
                )
            _REPORT_CTR += 1
    except Exception:
        pass
    return None


def current_report_count() -> int:
    """Sync in-memory counter with disk (throttled) and return it."""
    _init_report_counter()
    return _REPORT_CTR


def report_missing(card_id: str, school_name: str = "", student_class: str = "", missing: list = None) -> None:
    """Record that one or more card elements were missing.

    Prints a visible warning and appends a JSONL line to the report so the run
    can be audited afterwards. ``missing`` is a list of element names such as
    ``["stamp", "signature", "barcode", "school_logo"]``.
    """
    _init_report_counter()
    missing = missing or []
    if not missing:
        return
    context = ""
    if school_name or student_class:
        context = f" ({school_name} / {student_class})"
    try:
        from color_cli import color_text as _ct
        for name in missing:
            print(_ct(f"⚠ missing: {name}", "yellow") + f"  → card {card_id}{context}")
    except Exception:
        pass
    try:
        import threading as _threading
        lock = _report_lock if _report_lock is not None else _threading.Lock()
        with lock:
            with open(_report_path() + "l", "a", encoding="utf-8") as fh:
                fh.write(
                    json.dumps(
                        {
                            "user_id": card_id,
                            "task": "generate_card",
                            "status": "missing",
                            "missing": missing,
                            "school_name": school_name,
                            "student_class": student_class,
                        }
                    )
                    + "\n"
                )
    except Exception:
        pass


async def check_image_cache(user_id: str) -> dict:

    cache_image_path = (
        pathlib.Path(__file__).parent / "tmp" / "cache_images" / f"{user_id}.png"
    )
    if cache_image_path.exists():
        with open(cache_image_path, "rb") as cache_image:
            image_bytes = cache_image.read()
            base64_image = base64.b64encode(image_bytes).decode("utf-8")
            return {
                "status": True,
                "base64_image": f"data:image/png;base64,{base64_image}",
            }
    else:
        return {"status": False}


async def cache_image(id: str, image_bytes: bytes) -> None:

    cache_path = pathlib.Path(__file__).parent / "tmp" / "cache_images" / f"{id}.png"
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    with open(cache_path, "wb") as image_file:
        image_file.write(image_bytes)


# here we got a lot of work to do so the app work faster cause images are taking long to download
async def async_image_url_to_base64(
    session: aiohttp.ClientSession, image_url: str, user_id: str, counter: int
) -> Optional[str]:
    """
    Fetch image from URL and convert to base64 data URL

    Args:
        session: aiohttp ClientSession
        image_url: URL of the image

    Returns:
        Base64 encoded data URL or None if failed
    """
    try:

        # GET the image with timeout
        async with session.get(
            image_url, timeout=aiohttp.ClientTimeout(total=200)
        ) as response:

            # Check if request was successful
            if response.status != 200:
                print(f"[*] HTTP Error: {response.status} for {image_url}")
                return None
            else:

                from card_sdk.card_agent import count_cards

                inc = count_cards()

                from card_sdk.terminal_kid import Tkd

                with open(f"{base_dir}/report/users.json") as users_report:
                    total_users = json.loads(users_report.read())["total_users"]

                Tkd.inform_user(
                    f"{color_text(user_id[:4],"green")}"
                    + color_text(
                        "... Generating user profile photo format=Baseb64 \n _________________________________________________________________________",
                        "dark_grey",
                    )
                )
                Tkd.hello()

                print(
                    color_text(
                        f"\n [-] Please wait ....                       "
                        + color_text(
                            f"{(total_users - inc)} students / {total_users} students",
                            "green",
                        )
                        + "\n",
                        "yellow",
                    )
                )

                progress.update((inc / total_users) * 100)

                await cards_report(user_id, status="completed")

            # Get content type
            content_type = response.headers.get("Content-Type", "image/jpeg")

            # CRITICAL: Read the content as bytes
            image_bytes = await response.read()

            # Check if we got data
            if not image_bytes:
                print(f"[*] Empty response for {image_url}")
                return None
            # cance the image to cache folder Folder: /tmp/cache_images
            await cache_image(user_id, image_bytes)

            # Encode to base64
            image_base64 = base64.b64encode(image_bytes).decode("utf-8")

            # Return as data URL
            return f"data:{content_type};base64,{image_base64}"

    except asyncio.TimeoutError:
        print(f"[*] Timeout fetching {image_url}")
        return None
    except aiohttp.ClientError as e:
        print(f"[*] Client error fetching {image_url}: {e}")
        return None
    except Exception as e:
        print(f"[*] Unexpected error fetching {image_url}: {e}")
        return None


async def single_image_url_to_base64(image_url: str, user_id: str) -> Optional[str]:
    """
    Fetch image from URL and convert to base64 data URL

    Args:
        image_url: URL of the image
        user_id: User ID for reporting

    Returns:
        Base64 encoded data URL or None if failed
    """
    try:
        # GET the image with timeout
        response = requests.get(image_url, timeout=200)

        # Check if request was successful
        if response.status_code != 200:
            print(f"[*] HTTP Error: {response.status_code} for {image_url}")
            await cards_report(user_id, status="completed")  # ❌ Can't use await here!
            return None

        # Get content type
        content_type = response.headers.get("Content-Type", "image/jpeg")

        # Get the content as bytes
        image_bytes = response.content

        # Check if we got data
        if not image_bytes:
            print(f"[*] Empty response for {image_url}")
            return None

        # Encode to base64
        image_base64 = base64.b64encode(image_bytes).decode("utf-8")

        # Return as data URL
        return f"data:{content_type};base64,{image_base64}"

    except requests.Timeout:
        print(f"[*] Timeout fetching {image_url}")
        return None
    except requests.RequestException as e:
        print(f"[*] Request error fetching {image_url}: {e}")
        return None
    except Exception as e:
        print(f"[*] Unexpected error fetching {image_url}: {e}")
        return None


def clear_report_file():
    global _REPORT_CTR, _report_ctr_initialized
    _REPORT_CTR = 0
    _report_ctr_initialized = False
    try:
        open(_report_path(), "w", encoding="utf-8").write("[]")
        open(_report_path() + "l", "w", encoding="utf-8").close()
    except OSError:
        pass


if __name__ == "__main__":
    pass
