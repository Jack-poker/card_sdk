import asyncio
import pathlib
import requests
from prettytable import PrettyTable
from color_cli import color_text
from datetime import datetime
from jload import jsave

tb = PrettyTable()

tb.header = False

patch_path = pathlib.Path(__file__).parent / "patch"


async def upload_template() -> dict:
    try:

        with open(
            f"{patch_path}/card_patch.zip",
            "rb",
        ) as file, open(
            f"{patch_path}/patch.json",
            "rb",
        ) as json_patch_file:

            patch_time = str(datetime.now())

            jsave(
                {
                    "latest_patch_at": patch_time,
                    "patch_file": f"card_patch_update_{patch_time}.zip",
                },
                file_path=f"{patch_path}/patch.json",
            )

            files = {
                "patch_file": (f"patch.json", json_patch_file, "application/json"),
                "zip_file": (f"card_patch_update_{patch_time}.zip", file, "application/zip"),
            }
            uploadRes = requests.patch(
                url="https://automation.kaascan.com/webhook/template/upload",
                files=files,
                data={
                    "latest_patch_at": patch_time,
                    "patch_file": f"card_patch_update_{patch_time}.zip",
                },
            )

            jsonRes = uploadRes.json()
            tb.add_row(
                [
                    color_text("check-patch"),
                    "::"
                    + color_text(
                        jsonRes["status"],
                        "green" if "patched" in jsonRes["status"] else "red",
                    ),
                ]
            )
            print(tb)

    except Exception as error:
        print(f"uploading template failed: {error}")


asyncio.run(upload_template())
