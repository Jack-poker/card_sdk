import json
import os
from typing import Dict, Optional,Any

import ui
from card_sdk.terminal_kid import Tkd
from card_sdk.card import (clear_report_file,base_dir,single_image_url_to_base64,generate_card,Student,save_card,image_url_to_base64,base64_qrcode)
import asyncio
import time
import aiohttp
import subprocess
from joblib import Parallel,delayed
import requests
import requests_cache
from color_cli import color_text
from super_progress_bar import Progress
from jload import jsave


prg = 0

progress = Progress(
    min_value=0,
    max_value=100,
    unit="items",
    colors=[(0, 0, 0), (255, 255, 0), (255, 255, 0),(0, 0, 0)],
    single_color=False
)




# Student.photo = image_url_to_base64("https://admin.kaascan.com/assets/3a5e8e31-2a75-41b8-82ee-868127cb7562?download=")
# Student.name = "Fraterine Ely"
# Student.Class = "Software Devlopment"
# Student.school_name = "Lyce de nyanza"
# Student.data_qrcode = base64_qrcode({"name":"emmanuelzzzzzzzz"})

async def total_users(data_url =  "https://api.v2.kaascan.com/admin/students") -> dict:
    try:
        # Get user data
        response = requests.get(data_url,
        headers={
            'accept': 'application/json',
            'X-API-KEY': 'ykxiPah7Uc327P6sSeZ6KhXqnLwV6nxIYuVjooOInOO3ko26xgbJGz1VG'
        })
       
        total_users = response.json()["count"]

        jsave({ "total_users": total_users },file_path=f"{base_dir}/report/users.json")


        return total_users

    except Exception as error:
        print(f"[-] something went wrong: {error}")


# students
async def fetch_userdata(data_url: str) -> dict:
    try:
        # Get user data
        response = requests.get(data_url,
        headers={
            'accept': 'application/json',
            'X-API-KEY': 'ykxiPah7Uc327P6sSeZ6KhXqnLwV6nxIYuVjooOInOO3ko26xgbJGz1VG'
        })
        user_data = response.json()["data"]
        total_users = response.json()["count"]
        
        # Process all students concurrently
        connector = aiohttp.TCPConnector(resolver=aiohttp.ThreadedResolver())
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = []
            inc = 0
            for data in user_data:
                
                Tkd.checking_task_progress("Fetching users data",float(inc/(total_users/100)))
                inc+=1

                # Get the total number of users to make the process for::
              
                # Create task for each student
                task = process_student(session, data, inc)
                tasks.append(task)

            print(color_text(f"[>] Fetching users data Completed.","green"))
            # Execute all tasks at once
            results = await asyncio.gather(*tasks, return_exceptions=True)
            return results
            
    except Exception as e:
        print(f"[*] FETCHING USER DATA FAILED: {e}")
        return []



async def process_student(session, data, count: int):
    """Process single student"""

    # prg += 1
    # os.system("clear")
    # print(progress.update(prg))
    

    return {
        "student_photo": await image_url_to_base64(session, data["student_photo_url"], data["student_id"],count),
        "student_name": data["student_name"],
        "student_class": data["grade"],
        "school_name": data["school_name"],
        "data_qrcode": base64_qrcode({"student_id": data["student_id"]}),
        "student_id": data["student_id"]
    }



async def single_card(data: Student) -> str:

    result = generate_card(
              image_base64 = await single_image_url_to_base64(data.photo,user_id=data.student_id),
              student_name = data.name,
              student_class = data.Class,
              data_qrcode = base64_qrcode(data.data_qrcode),
              school_name = data.school_name,
              student_id = data.student_id
          )

    Tkd.checking_task_progress(result,80)
    print(color_text("[-] Single card generated successful. \n \n","light_green"))
    print(color_text(f"[-] Check output folder: {base_dir}/output/ \n \n","light_green"))
    
    return result

def count_cards():
    with open(f"{base_dir}/report/cards_report.json","r") as report_file:
        all_cards = json.loads(report_file.read())
        return len(all_cards)


async def multiple_cards(data_url =  "https://api.v2.kaascan.com/admin/students"):
      # Fetch users data
      user_data = await fetch_userdata(data_url)

      # Generate card content
      results = Parallel(n_jobs = -1)( delayed(generate_card)(
              image_base64=data["student_photo"],
              student_name=data["student_name"],
              student_class=data["student_class"],
              data_qrcode=data["data_qrcode"],
              school_name=data["school_name"],
              student_id = data["student_id"]
          )   for data in user_data )


      for result in results:
          
          Tkd.inform_user(result)
          Tkd.hello()

          return result

def create_output_Folder():
    if not os.path.exists("output"):
        os.system("mkdir output")
    else:
        pass
    





class Card:

    async def agent(data = None):
        # create output folder
        create_output_Folder()
        #make template update
        from card_sdk.update import update_template
        print("\n \n [*] updating [O]")
        await update_template()
        print("[*] updating Finished [1]")

        Tkd.cleaner()

        Tkd.hello()

        modes = ["single","multiple"]

        mode = ui.ask_choice("Choose generating mode: ", modes)
        
        # Clear the report file
        clear_report_file()
        # get total users number
        await total_users()

        try:

            Tkd.hello()

            if mode == "single" and data != None:
        
               singleCard_result = await single_card(data)
    
            if mode == "multiple":
                   multipleCards = await multiple_cards()

        except KeyError as error:
            raise("byee")

        



            
           
        
        

    






